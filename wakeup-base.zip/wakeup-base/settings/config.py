import os
import torch

os.environ["CUDA_VISIBLE_DEVICES"] = "8"
TRAIN_DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
PIN_YIN_CONFIG_PATH = './pin_yin_config.txt'
HOP_SIZE = 256

# ERROR
ERROR_KWS_DIR = ''

# NOISE
NOISE_PARTS_NUM = 20
TRAINING_NOISE = '/datapool/deep_learning/userspace/zhangkanghao/data/noise/fp16k/diffuse-noise'
WIND_NOISE_PATH = '/datapool/deep_learning/userspace/zhangkanghao/data/projects/shunwei-normandy/trainset/noise-wind'
POINT_NOISE_PATH = '/datapool/deep_learning/userspace/zhangkanghao/data/noise/fp16k/point-noise/noise-10k'
ROAD_SNR_LIST = [3, 10]
POINT_SNR_LIST = [5, 15]

# RIR
TRAINING_RIR = {
       'L1': {'rir': ['/datapool/deep_learning/userspace/zhangkanghao/data/projects/desai-langjing/filters/lanjing7.0/split/1L'], 'channel': 0},
       'R1': {'rir': ['/datapool/deep_learning/userspace/zhangkanghao/data/projects/desai-langjing/filters/lanjing7.0/split/1R'], 'channel': 1},
}

# KEYWORD
TRAINING_BACKGROUND = [
    # asr data
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/aidatatang_1505h.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/aidatatang_200h.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/aishell2.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/aishell3.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/bznsyp.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/magicdata.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/mozilla.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/primewords.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/st_cmd.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/TAL_ASR.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/thchs30.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/wenetwpeech.pickle',
    # keywords data
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/三D模式.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/二D模式.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/你好悠悠.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/停止导航.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/停止播放.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/关闭声音.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/关闭空调.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/关闭透传.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/关闭降噪.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/减小音量.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/取消.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/取消全览.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/取消导航.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/向右.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/向左.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/回到桌面.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/增大音量.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/大点声.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/导航去公司.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/导航回家.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/小创小创.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/小憩模式.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/小点声.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/小艺小艺.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/小薇小薇.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/小贝小贝.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/开启透传.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/开启降噪.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/开始导航.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/开始播放.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/开始泊车.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/微信支付.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/快速净化.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/我要听歌.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/打开地图.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/打开声音.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/打开导航.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/打开空调.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/挂断.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/挂断电话.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/接听.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/接听电话.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/播放下一频道.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/播放下一首.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/播放音乐.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/支付宝扫一扫.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/支付宝支付.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/收藏歌曲.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/收藏这首歌.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/放大地图.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/暂停播放.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/查看全程.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/查看全览.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/正北朝上.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/爱宝爱宝.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/确定.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/第一个.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/第七个.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/第三个.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/第九个.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/第二个.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/第五个.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/第八个.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/第六个.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/第十一个.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/第十个.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/第十二个.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/第四个.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/继续导航.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/继续播放.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/缩小地图.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/订阅专辑.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/调大音量.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/调小音量.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/车头朝上.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/还有多久.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/还有多远.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/退出全程.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/退出全览.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/退出导航.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/你好保时捷.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/你好保时捷导航回家.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/你好小智.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/你好小智导航回家.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/你好小迪.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/你好小迪导航回家.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/嘿保时捷.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/嘿保时捷导航回家.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/理想同学.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/你好北鼻.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/你好奥迪.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/你好小婕.pickle',
    '/datapool/deep_learning/share/kws-asr/chinese/pickle/小婕你好.pickle',
    
]

TRAINING_KEY_WORDS = [
    [
        '/datapool/deep_learning/share/kws-asr/chinese/pickle/核数聚_小溪小溪.pickle',
    ],
]

TRAINING_CHECK_PATH = './check'

# PARAM
LR = 1e-3
BATCH_SIZE = 64
RESUME_MODEL = False 
MODEL_DIR = './model/checkpoints'
if not os.path.exists(MODEL_DIR):
    os.makedirs(MODEL_DIR)
MODEL_NAME = ''
PRINT_TIMES = 100
TEST_TIMES = 1000
TRAIN_FRQ_RESPONSE = '/datapool/deep_learning/userspace/zhangkanghao/data/filter/fir/fir_1000000.npy'
