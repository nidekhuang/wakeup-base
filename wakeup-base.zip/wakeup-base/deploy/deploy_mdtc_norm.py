#!/usr/bin/env python3
# Copyright (c) 2021 Jingyong Hou (houjingyong@gmail.com)
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from typing import OrderedDict
import torch
import librosa
import random
import numpy as np
import torch.nn as nn
import torch.nn.functional as F
from tools.torch_stft import STFT
from component.time_vad import TimeVad


def resume_model(net, models_path, device='cpu'):
    # if is_map_to_cpu or not torch.cuda.is_available():
    model_dict = torch.load(models_path, map_location=device)
    state_dict = model_dict['state_dict']
    for k, v in net.state_dict().items():
        if k.split('.')[0] == 'module':
            net_has_module = True
        else:
            net_has_module = False
        break
    dest_state_dict = OrderedDict()
    for k, v in state_dict.items():
        if k.split('.')[0] == 'module':
            ckpt_has_module = True
        else:
            ckpt_has_module = False
        if net_has_module == ckpt_has_module:
            dest_state_dict = state_dict
            break
        if ckpt_has_module:
            dest_state_dict[k.replace('module.', '')] = v
        else:
            dest_state_dict['module.{}'.format(k)] = v

    net.load_state_dict(dest_state_dict, False)
    step = model_dict['step']
    optim_state = model_dict['optimizer']
    print('finish to resume model {}.'.format(models_path))
    return step, optim_state

class STFT(torch.nn.Module):
    def __init__(self, win_len=1024, shift_len=512, window=None):
        super(STFT, self).__init__()
        if window is None:
            window = torch.from_numpy(np.sqrt(np.hanning(win_len).astype(np.float32)))
        self.win_len = win_len
        self.shift_len = shift_len
        self.window = window
    
    def transform(self, input_data):
        self.window = self.window.to(input_data.device)
        spec = torch.stft(input_data, n_fft=self.win_len, hop_length=self.shift_len, win_length=self.win_len, window=self.window, center=True, pad_mode='constant', return_complex=True)
        spec = torch.view_as_real(spec)
        return spec.permute(0, 2, 1, 3)
    
    def inverse(self, spec):
        self.window = self.window.to(spec.device)
        torch_wav = torch.istft(torch.view_as_complex(torch.permute(spec, [0, 2, 1, 3])), n_fft=self.win_len, hop_length=self.shift_len, win_length=self.win_len, window=self.window, center=True)
        return torch_wav
    
    def forward(self, input_data):
        stft_res = self.transform(input_data)
        reconstruction = self.inverse(stft_res)
        return reconstruction

class TimeVad(object):
    def __init__(self, shift=256):
        super(TimeVad, self).__init__()
        self.shift = shift

    def __frame__(self, in_wav):
        b, t = in_wav.size()
        padding_size = int(np.ceil(in_wav.shape[-1] / self.shift)) * self.shift - in_wav.shape[-1]
        if padding_size > 0:
            pad_wav = torch.cat([in_wav, torch.zeros([b, padding_size], device=in_wav.device)], dim=-1)
        else:
            pad_wav = torch.ones_like(in_wav) * in_wav
        frame_wav = pad_wav.reshape([b, -1, self.shift])
        return frame_wav

    def __call__(self, in_wav):
        frame_wav = self.__frame__(in_wav)
        pow = (frame_wav ** 2).sum(-1)
        pow_db = 10 * torch.log10(pow + 1e-7)
        threshold = pow_db[:, :20].amax(-1, keepdim=True) + 10
        # sorted, indices = torch.sort(pow_db, dim=-1)
        # mean_pow = sorted[:, -50:].mean(-1, keepdim=True)
        # threshold = mean_pow - 15
        frame_vad = torch.where(pow_db <= threshold, torch.zeros_like(pow_db),
                                torch.ones_like(pow_db)).unsqueeze(dim=-1)
        # in_wav为全0时，mean_pow为-70
        zero_check = torch.where(threshold < -60, torch.zeros_like(pow_db), torch.ones_like(pow_db))
        frame_vad = frame_vad * zero_check.unsqueeze(dim=-1)
        sample_vad = frame_vad.repeat(1, 1, self.shift).reshape(in_wav.shape[0], -1)[:, :in_wav.shape[-1]]
        return frame_vad, sample_vad

class CTC(torch.nn.Module):
    """CTC module"""
    def __init__(
        self,
        reduce: bool = True,
    ):
        """ Construct CTC module
        Args:
            odim: dimension of outputs
            encoder_output_size: number of encoder projection units
            dropout_rate: dropout rate (0.0 ~ 1.0)
            reduce: reduce the CTC loss into a scalar
        """
        super().__init__()

        reduction_type = "sum" if reduce else "none"
        self.ctc_loss = torch.nn.CTCLoss(reduction=reduction_type)

    def forward(self, ys_hat: torch.Tensor, hlens: torch.Tensor,
                ys_pad: torch.Tensor, ys_lens: torch.Tensor) -> torch.Tensor:
        """Calculate CTC loss.

        Args:
            hs_pad: batch of padded hidden state sequences (B, Tmax, D)
            hlens: batch of lengths of hidden state sequences (B)
            ys_pad: batch of padded character id sequence tensor (B, Lmax)
            ys_lens: batch of lengths of character sequence (B)
        """
        # ys_hat: (B, L, D) -> (L, B, D)
        ys_hat = ys_hat.transpose(0, 1)
        ys_hat = ys_hat.log_softmax(2)
        loss = self.ctc_loss(ys_hat, ys_pad, hlens, ys_lens)
        # Batch-size average
        loss = loss / ys_hat.size(1)
        return loss

    def softmax(self, hs_pad: torch.Tensor) -> torch.Tensor:
        return F.softmax(self.ctc_lo(hs_pad), dim=2)

    def log_softmax(self, hs_pad: torch.Tensor) -> torch.Tensor:
        """log_softmax of frame activations

        Args:
            Tensor hs_pad: 3d tensor (B, Tmax, eprojs)
        Returns:
            torch.Tensor: log softmax applied 3d tensor (B, Tmax, odim)
        """
        return F.log_softmax(self.ctc_lo(hs_pad), dim=2)

    def argmax(self, hs_pad: torch.Tensor) -> torch.Tensor:
        """argmax of frame activations

        Args:
            torch.Tensor hs_pad: 3d tensor (B, Tmax, eprojs)
        Returns:
            torch.Tensor: argmax applied 2d tensor (B, Tmax)
        """
        return torch.argmax(self.ctc_lo(hs_pad), dim=2)

class Fbank(nn.Module):
    def __init__(self, sample_rate=16000, filter_length=512, hop_length=256, n_mels=64):
        super(Fbank, self).__init__()
        self.stft = STFT(filter_length, hop_length)
        self.alpha = nn.Parameter(torch.FloatTensor(1, 257))
        nn.init.constant_(self.alpha, 3)
        # self.ln = nn.LayerNorm([5, 16])
        self.linear_to_mel_weight_matrix = torch.from_numpy(librosa.filters.mel(sr=sample_rate,
                                                                                n_fft=filter_length,
                                                                                n_mels=n_mels,
                                                                                fmin=20,
                                                                                fmax=8000,
                                                                                htk=True,
                                                                                norm=None).T.astype(np.float32))
    def spec_aug(self, spec, num_t_mask=2, num_f_mask=3, max_t=3, max_f=5):
        b, t, f, _ = spec.size()
        for i in range(b):
            if random.random() < 0.3:
                for j in range(num_t_mask):
                    start = random.randint(0, t - 1)
                    length = random.randint(1, max_t)
                    end = min(t, start + length)
                    spec[i, start:end] = 0
                
                for j in range(num_f_mask):
                    start = random.randint(0, f - 1)
                    length = random.randint(1, max_f)
                    end = min(f, start + end)
                    spec[i, :, start:end] = 0
        return spec
    
    
    def forward(self, input_waveform):
        with torch.no_grad():
            spec = self.stft.transform(input_waveform) # [1, 626, 257, 2]
            spec[:, :, 0, :] = 0
            # if self.training:
            #     spec = self.spec_aug(spec)
            mag = (spec ** 2).sum(-1).sqrt()
        abs_mel = torch.matmul(mag, self.linear_to_mel_weight_matrix.to(input_waveform.device))
        abs_mel = abs_mel + 1e-6
        log_mel = abs_mel.log()
        log_mel[log_mel < -6] = -6
        return log_mel

class DSDilatedConv1d(nn.Module):
    """Dilated Depthwise-Separable Convolution"""
    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        kernel_size: int,
        dilation: int = 1,
        stride: int = 1,
        bias: bool = False,
    ):
        super(DSDilatedConv1d, self).__init__()
        self.receptive_fields = dilation * (kernel_size - 1)
        self.conv = nn.Conv1d(
            in_channels,
            in_channels,
            kernel_size,
            padding=0,
            dilation=dilation,
            stride=stride,
            groups=in_channels,
            bias=bias,
        )
        self.convbn = nn.BatchNorm1d(in_channels)
        self.pointwise = nn.Conv1d(in_channels,
                                   out_channels // 2,
                                   kernel_size=1,
                                   padding=0,
                                   dilation=1,
                                   bias=bias)
        self.pointwisebn = nn.BatchNorm1d(out_channels // 2)

    def forward(self, inputs: torch.Tensor):
        outputs = self.convbn(self.conv(inputs))
        outputs = self.pointwisebn(self.pointwise(outputs))
        return outputs

class TCNBlock(nn.Module):
    def __init__(
        self,
        in_channels: int,
        res_channels: int,
        kernel_size: int,
        dilation: int,
        causal: bool,
    ):
        super(TCNBlock, self).__init__()
        self.in_channels = in_channels
        self.res_channels = res_channels
        self.kernel_size = kernel_size
        self.dilation = dilation
        self.causal = causal
        self.receptive_fields = dilation * (kernel_size - 1)
        self.half_receptive_fields = self.receptive_fields // 2
        self.conv1 = DSDilatedConv1d(
            in_channels=in_channels,
            out_channels=res_channels,
            kernel_size=kernel_size,
            dilation=dilation,
        )
        self.prelu1 = nn.PReLU(res_channels // 2)

        self.conv2 = nn.Conv1d(in_channels=res_channels // 2,
                               out_channels=res_channels,
                               kernel_size=1)
        self.conv2bn = nn.BatchNorm1d(res_channels)
        self.prelu2 = nn.PReLU(res_channels)

    def forward(self, xs: torch.Tensor, xs_lens=None, cnn_cache=None, is_last_cache=False):
        if cnn_cache is None:
            # inputs = F.pad(xs, (self.receptive_fields, 0, 0, 0, 0, 0),
            #                 'constant')
            cnn_cache = torch.zeros([xs.shape[0], xs.shape[1], self.receptive_fields], dtype=xs.dtype, device=xs.device)
        inputs = torch.cat((cnn_cache, xs), dim=-1)
        if xs_lens is None or is_last_cache:
            new_cache = inputs[:, :, -self.receptive_fields:]
        else:
            new_cache = []
            for i, xs_len in enumerate(xs_lens):
                c = inputs[i:i+1, :, xs_len:xs_len+self.receptive_fields]
                new_cache.append(c)
            new_cache = torch.cat(new_cache, axis=0)
        # new_cache = inputs[:, :, -self.receptive_fields:]

        outputs1 = self.prelu1(self.conv1(inputs))
        outputs2 = self.conv2(outputs1)
        inputs = inputs[:, :, self.receptive_fields:]  
        if self.in_channels == self.res_channels:
            res_out = self.prelu2(self.conv2bn(outputs2) + inputs)
        else:
            res_out = self.prelu2(self.conv2bn(outputs2))
        return res_out, new_cache.detach(), [outputs1, outputs2, res_out]
    
    def fuse_module(self):
        x = torch.randn(1, self.in_channels, 100)
        y1 = self(x)[0]
        torch.quantization.fuse_modules(self, [
            ['conv1.conv', 'conv1.convbn'], 
            ['conv1.pointwise', 'conv1.pointwisebn'],
            ['conv2', 'conv2bn']
            ], 
            inplace=True)
        y2 = self(x)[0]
        e = torch.abs(y1 - y2).max().item()
        print(f"融合误差: {e:.10f}")

    # def fuse_module(self):
    #     w, b = fuse_conv_bn(self.conv1.conv, self.conv1.convbn)
    #     x = torch.randn(1, w.shape[0], 100)
    #     new_conv = nn.Conv1d(
    #         in_channels=self.conv1.conv.in_channels,
    #         out_channels=self.conv1.conv.out_channels,
    #         kernel_size=self.conv1.conv.kernel_size,
    #         stride=self.conv1.conv.stride,
    #         padding=self.conv1.conv.padding,
    #         dilation=self.conv1.conv.dilation,
    #         groups=self.conv1.conv.groups,
    #         bias=True  # 确保有偏置
    #     )
    #     with torch.no_grad():
    #         y1 = self.conv1.convbn(self.conv1.conv(x))
    #         new_conv.weight.copy_(w)
    #         new_conv.bias.copy_(b)
    #         self.conv1.conv = new_conv
    #         self.conv1.convbn = nn.Identity()  # 设置为恒等层
    #         y2 = self.conv1.conv(x)
    #         e = torch.abs(y1 - y2).max().item()
    #         print(f"融合误差: {e:.10f}")
        

    #     w, b = fuse_conv_bn(self.conv1.pointwise, self.conv1.pointwisebn)
    #     x = torch.randn(1, w.shape[1], 100)
    #     new_convp = nn.Conv1d(
    #         in_channels=self.conv1.pointwise.in_channels,
    #         out_channels=self.conv1.pointwise.out_channels,
    #         kernel_size=self.conv1.pointwise.kernel_size,
    #         stride=self.conv1.pointwise.stride,
    #         padding=self.conv1.pointwise.padding,
    #         dilation=self.conv1.pointwise.dilation,
    #         groups=self.conv1.pointwise.groups,
    #         bias=True  # 确保有偏置
    #     )
    #     with torch.no_grad():
    #         y1 = self.conv1.pointwisebn(self.conv1.pointwise(x))
    #         new_convp.weight.copy_(w)
    #         new_convp.bias.copy_(b)
    #         self.conv1.pointwise = new_convp
    #         self.conv1.pointwisebn = nn.Identity()  # 设置为恒等层
    #         y2 = self.conv1.pointwisebn(self.conv1.pointwise(x))
    #         e = torch.abs(y1 - y2).max().item()
    #         print(f"融合误差: {e:.6f}")

    #     w, b = fuse_conv_bn(self.conv2, self.conv2bn)
    #     x = torch.randn(1, w.shape[1], 100)
    #     with torch.no_grad():
    #         y1 = self.conv2bn(self.conv2(x))
    #         new_conv2 = nn.Conv1d(
    #             in_channels=self.conv2.in_channels,
    #             out_channels=self.conv2.out_channels,
    #             kernel_size=self.conv2.kernel_size,
    #             stride=self.conv2.stride,
    #             padding=self.conv2.padding,
    #             dilation=self.conv2.dilation,
    #             groups=self.conv2.groups,
    #             bias=True  # 确保有偏置
    #         )
    #         new_conv2.weight.copy_(w)
    #         new_conv2.bias.copy_(b)
    #         self.conv2 = new_conv2
    #         self.conv2bn = nn.Identity()  # 设置为恒等层
    #         y2 = self.conv2bn(self.conv2(x))
    #         e = torch.abs(y1 - y2).max().item()
    #         print(f"融合误差: {e:.6f}")

    #     return

class TCNStack(nn.Module):
    def __init__(
        self,
        in_channels: int,
        stack_num: int,
        res_channels: int,
        kernel_size: int,
        causal: bool,
    ):
        super(TCNStack, self).__init__()
        assert causal is True
        self.in_channels = in_channels
        self.stack_num = stack_num
        # self.stack_size = stack_size
        self.res_channels = res_channels
        self.kernel_size = kernel_size
        self.causal = causal
        self.res_blocks = self.stack_tcn_blocks()
        self.receptive_fields = self.calculate_receptive_fields()
        self.res_blocks = nn.Sequential(*self.res_blocks)

    def calculate_receptive_fields(self):
        receptive_fields = 0
        for block in self.res_blocks:
            receptive_fields += block.receptive_fields
        return receptive_fields

    def build_dilations(self):
        dilations = []
        # for s in range(0, self.stack_size):
        for l in range(0, self.stack_num):
            dilations.append(2**l)
        return dilations

    def stack_tcn_blocks(self):
        dilations = self.build_dilations()
        res_blocks = nn.ModuleList()

        res_blocks.append(
            TCNBlock(
                self.in_channels,
                self.res_channels,
                self.kernel_size,
                dilations[0],
                self.causal,
            ))
        for dilation in dilations[1:]:
            res_blocks.append(
                TCNBlock(
                    self.res_channels,
                    self.res_channels,
                    self.kernel_size,
                    dilation,
                    self.causal,
                ))
        return res_blocks

    def forward(self, xs: torch.Tensor, xs_lens=None, cnn_caches=None, is_last_cache=False):
        new_caches = []
        out_list_for_loss = []
        for block, cnn_cache in zip(self.res_blocks, cnn_caches):
            xs, new_cache, out_l = block(xs, xs_lens, cnn_cache, is_last_cache=is_last_cache)
            new_caches.append(new_cache)
            out_list_for_loss += out_l
        return xs, new_caches, out_list_for_loss

    def fuse_module(self,):
        for layer in self.res_blocks:
            layer.fuse_module()

class MDTCSML(nn.Module):
    """Multi-scale Depthwise Temporal Convolution (MDTC).
    In MDTC, stacked depthwise one-dimensional (1-D) convolution with
    dilated connections is adopted to efficiently model long-range
    dependency of speech. With a large receptive field while
    keeping a small number of model parameters, the structure
    can model temporal context of speech effectively. It aslo
    extracts multi-scale features from different hidden layers
    of MDTC with different receptive fields.
    """
    def __init__(
        self,
        stack_num: int,
        stack_size: int,
        in_channels: int,
        res_channels: int,
        kernel_size: int,
        causal: bool,
        shift=320
    ):
        super(MDTCSML, self).__init__()
        self.layer_norm = nn.LayerNorm([5, 2])
        self.kernel_size = kernel_size
        self.causal = causal
        self.preprocessor = TCNBlock(in_channels,
                                     res_channels,
                                     kernel_size,
                                     dilation=1,
                                     causal=causal)
        self.prelu = nn.PReLU(res_channels)
        self.blocks = nn.ModuleList()
        self.receptive_fields = []
        self.receptive_fields.append(self.preprocessor.receptive_fields)
        for _ in range(stack_num):
            self.blocks.append(
                TCNStack(res_channels, stack_size, res_channels,
                         kernel_size, causal))
            self.receptive_fields.append(self.blocks[-1].receptive_fields)
        self.pooling_cnn = nn.Conv2d(in_channels=stack_num, out_channels=1, kernel_size=(1, 1), bias=False)
        self.pooling_relu = nn.PReLU(1)
        self.stack_num = stack_num
        self.stack_size = stack_size
        
        self.fbank = Fbank(sample_rate=16000, filter_length=shift * 2, hop_length=shift, n_mels=64)
        self.time_vad = TimeVad(256)
        vocab_size = 410 # 拼音分类
        self.pinyin_fc = torch.nn.Linear(res_channels, vocab_size)
        self.class_fc = torch.nn.Linear(res_channels, 7)
        self.ctc = CTC()
        self.drop_out = nn.Dropout(p=0.1)
        self.shift = shift

    def forward(self, wav, kw_target=None, ckw_target=None, real_frames=None, label_frames=None, ckw_len=None, clean_speech=None, hidden=None, custom_in=None):
        if hidden is None:
            hidden = [None for _ in range(self.stack_size * self.stack_num + 1)]
        else:
            if hidden[0].shape[0] >= wav.shape[0]:
                b = wav.size(0)
                h_l = []
                for h in hidden:
                    h_l.append(h[:b])
                hidden = h_l
            else:
                hidden = [None for _ in range(self.stack_size * self.stack_num + 1)]
        
        xs = self.fbank(wav)
            
        b, t, f = xs.size()
        if random.random() < 0.5 and self.training:
            is_last_cache = True
        else:
            is_last_cache = False
        outputs = xs.transpose(1, 2)
        outputs_list = []
        outputs_list_for_loss = []
        outputs_cache_list  = []
        outputs, new_cache,  o_l_1= self.preprocessor(outputs, real_frames, hidden[0], is_last_cache=is_last_cache)
        outputs_list_for_loss += o_l_1
        outputs = self.prelu(outputs)
        outputs_list_for_loss.append(outputs)
        outputs_pre = outputs
        outputs_cache_list.append(new_cache)
        for i in range(len(self.blocks)):
            outputs, new_caches, o_l_tmp = self.blocks[i](outputs, real_frames, hidden[1+i*self.stack_size: 1 +(i+1)*self.stack_size], is_last_cache=is_last_cache)
            outputs_list_for_loss += o_l_tmp
            outputs_list.append(outputs)
            outputs_cache_list += new_caches

        outputs = sum(outputs_list)
        outputs = outputs.transpose(1, 2)
        pinyin_logist = self.pinyin_fc(outputs_list[1].transpose(1, 2))
        logist = self.class_fc(outputs)

        return logist
    
    def fuse_module(self, ):
        self.preprocessor.fuse_module()
        for i in range(len(self.blocks)):
            self.blocks[i].fuse_module()
        print()

def fuse_conv_bn(conv, bn):
    conv_weight = conv.weight.data.clone()
    if conv.bias is None:
        conv_bias = torch.zeros(conv_weight.shape[0], dtype=torch.float32)
    else:
        conv_bias = conv.bias.data.clone()
    
    # 2. 获取BN参数
    bn_gamma = bn.weight.data.clone()
    bn_beta = bn.bias.data.clone()
    bn_mean = bn.running_mean.data.clone()
    bn_var = bn.running_var.data.clone()
    bn_eps = bn.eps
    
    # 3. 计算融合参数
    std = torch.sqrt(bn_var + bn_eps)
    scale_factor = bn_gamma / std
    
    # 5. 计算融合后的权重和偏置
    fused_weight = conv_weight * scale_factor.reshape([-1] + [1] * (len(conv_weight.shape) - 1))
    fused_bias = bn_beta + (conv_bias - bn_mean) * scale_factor

    return fused_weight, fused_bias



if __name__ == '__main__':
    THRES_HOLD = 0.5
    from network.mdtc import MDTCSML
    net_work = MDTCSML(stack_num=4, stack_size=4, in_channels=64, res_channels=128, kernel_size=7, causal=True, num_classes=8)
    resume_model(net_work, './model/class7_model/model-2106000--117.39986686706543.pickle')
    net_work.eval()

    import soundfile as sf
    f_paths = [
        ('./deploy/wind.wav', 0),
        # ('./deploy/小溪小溪.wav', 0),
        # ('./deploy/下一首.wav', 1),
        # ('./deploy/开始拍照.wav', 2),
        # ('./deploy/开始录像.wav', 3),
        # ('./deploy/结束录像.wav', 4),
        # ('./deploy/帮我看看.wav', 5),
    ]
    for i in range(len(f_paths)):
        data, _ = sf.read(f_paths[i][0])
        with torch.no_grad():
            data_in = torch.from_numpy(data.astype(np.float32)).reshape(1, -1)
            est_kws = torch.zeros_like(data_in)
            est_logist = net_work(data_in)[0]
            est_logist = est_logist
            est_logist, idx = (torch.softmax(est_logist, dim=-1).squeeze()[:, 1:]).max(1)

            count = 0
            k = 0
            while k < est_logist.size(0):
                if est_logist[k] > THRES_HOLD and idx[k] == f_paths[i][1]:
                    est_kws[:, k * 320] = 0.1 * (idx[k] + 1)
                    count += 1
                    k += 60
                else:
                    k += 1
            print(count)
            sf.write(f_paths[i][0].replace('.wav', '{}.wav'.format('.proc')), torch.cat([data_in, est_kws], dim=0).T, 16000)
    
    net_work.fuse_module()
    net_work.eval()
    torch.save({'state_dict': net_work.state_dict()}, './model/class7_model/model-2106000--117.39986686706543_fuse.pickle')
    for i in range(len(f_paths)):
        data, _ = sf.read(f_paths[i][0])
        with torch.no_grad():
            data_in = torch.from_numpy(data.astype(np.float32)).reshape(1, -1)
            est_kws = torch.zeros_like(data_in)
            est_logist = net_work(data_in)[0]
            est_logist = est_logist
            est_logist, idx = (torch.softmax(est_logist, dim=-1).squeeze()[:, 1:]).max(1)

            count = 0
            k = 0
            while k < est_logist.size(0):
                if est_logist[k] > THRES_HOLD and idx[k] == f_paths[i][1]:
                    est_kws[:, k * 320] = 0.1 * (idx[k] + 1)
                    count += 1
                    k += 60
                else:
                    k += 1
            print(count)
            sf.write(f_paths[i][0].replace('.wav', '{}.wav'.format('.proc')), torch.cat([data_in, est_kws], dim=0).T, 16000)