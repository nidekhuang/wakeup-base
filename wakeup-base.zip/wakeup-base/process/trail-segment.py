import os
import torch
import argparse
import numpy as np
import soundfile as sf
from pathlib import Path
from train.train_script_1mic import resume_model
from process.deploy_mdtc_norm import MDTCSML

def browse_dir(indir, suffix):
    for root, dirs, files in os.walk(indir):
        for filename in files:
            filename = os.path.join(root, filename)
            filename = filename.strip()
            if Path(filename).suffix.lower() not in ['.' + suffix]:
                continue
            if not os.path.exists(filename):
                continue
            yield filename

def process_model_epoch(model, path, args, files, log_writer):
    """处理单个模型epoch的函数"""
    try:
        resume_model(model, Path(path).parent, Path(path).stem)
    except:
        print(f'Load model error, {path}')
        return False, None
    
    print(f'ckpt-{Path(path).stem} has loaded!')
    results = {}
    total_count = 0
    
    for scene, scene_segs in files.items():
        scene_count = [0] * args.num_classes
        for file in scene_segs:
            # 读取音频文件
            if args.suffix == 'wav':
                mix, sr = sf.read(file)
            else:
                mix, sr = sf.read(file, channels=2, samplerate=16000, format='RAW', subtype='PCM_16')
                
            # 应用dB增益
            mix *= 10**(args.gain / 20.0)
            if len(mix.shape) == 1:
                mix = np.reshape(mix, [-1, 1])
                
            filename = Path(file).stem
            # temp: APP错误导致NLPI只有一个通道输出，取第一通道
            if 'NLPI' in file:
                mix = mix[:, :1]

            mag_cum = []
            scores = []
            indexs = []
            for ch in range(mix.shape[1]):
                mix_c = torch.from_numpy(mix[:, ch].astype(np.float32))
                with torch.no_grad():
                    mix_c = mix_c.unsqueeze(dim=0).to(args.device)
                    t = mix_c.size(-1)
                    est, mag = model(mix_c)
                    score, max_idx = (torch.softmax(est, dim=-1).squeeze()[:, 1:]).max(1)
                    scores.append(score)
                    indexs.append(max_idx)
                    mag_cum.append(torch.cumsum(mag.squeeze(0).sum(1), dim=0))
            scores = torch.stack(scores, axis=0)
            indexs = torch.stack(indexs, axis=0)
            mag_cum = torch.stack(mag_cum, axis=0)

            # 判断是否唤醒
            is_wake = False
            for frame_idx in range(scores.shape[1]):
                if is_wake:
                    break
                min_cum_mag = np.inf
                for ch in range(scores.shape[0]):
                    ch_score = scores[ch][frame_idx].item()
                    ch_id = indexs[ch][frame_idx].item()

                    if mag_cum[ch][frame_idx] < min_cum_mag:
                        min_cum_mag = mag_cum[ch][frame_idx]
                        cur_score = ch_score
                        cur_ch = ch
                        cur_id = ch_id
                    
                if cur_score > args.threshold:
                    is_wake = True
                    scene_count[cur_id] += 1
                    total_count += 1
                    break

            # print(f"{Path(file).stem}, {cur_id + 1 if is_wake else None}")
        results[scene] = scene_count
        print('{} has process!'.format(scene), scene_count)
    
    # 记录日志
    log_writer.write(f"{Path(path).stem}, {results}, total_count={total_count}\n")
    log_writer.flush()  
    
    return True, {'results': results, 'total_count': total_count}

def perform_model_comparison(all_model_results, args):
    """执行模型比较和筛选"""
    print('\n' + '='*50)
    print('开始模型比较和筛选...')
    
    # 筛选符合条件的模型
    valid_models = []
    
    for model_result in all_model_results:
        name = model_result['name']
        class_totals = model_result['class_totals']
        item_results = model_result['results']
        
        # 规则1：检查最低唤醒限制（针对每个文件）
        meets_min_requirements = True
        for file_idx, file_result in item_results.items():
            # file_result: [[key1, key2, ...](ch1), [key1, key2, ...](ch2), ...]
            per_file_class_counts = [0] * len(args.min_wake_limits)
            for class_idx, count in enumerate(file_result):
                per_file_class_counts[class_idx] += count
            for class_idx, count in enumerate(per_file_class_counts):
                if count < args.min_wake_limits[class_idx]:
                    meets_min_requirements = False
                    print(f"{name} 被淘汰: 文件{file_idx} 类别{class_idx}唤醒次数{count} < 最低限制{args.min_wake_limits[class_idx]}")
                    break
            if not meets_min_requirements:
                break
        if not meets_min_requirements:
            continue
        
        # 规则2和3：由于已在计算class_totals时应用了单文件上限，这里直接累加
        effective_total = sum(class_totals)
        
        valid_models.append({
            'name': name,
            'class_totals': class_totals,
            'effective_total': effective_total,
            'original_total': model_result['total_count']
        })
        
        print(f"{name} 通过筛选: 各类别唤醒{class_totals}, 有效总数{effective_total}")
    
    # 规则3：根据有效唤醒总数排序，推荐前N个模型
    if valid_models:
        valid_models.sort(key=lambda x: x['effective_total'], reverse=True)
        top_models = valid_models[:args.top_n_models]
        
        print(f'\n推荐前{len(top_models)}个模型:')
        print('-' * 80)
        print(f"{'排名':<6}{'模型':<12}{'各类别唤醒次数':<30}{'有效总数':<10}{'原始总数':<10}")
        print('-' * 80)
        
        for rank, model in enumerate(top_models, 1):
            class_str = str(model['class_totals'])
            print(f"{rank:<6}{model['name']:<40}{class_str:<40}{model['effective_total']:<10}{model['original_total']:<10}")
        
        # 将推荐结果写入文件
        recommendation_file = f'{args.result_dir}/model_recommendation-{args.tag}.txt'
        with open(recommendation_file, 'a') as f:
            f.write("模型推荐报告\n")
            f.write("="*50 + "\n")
            f.write(f"筛选条件:\n")
            f.write(f"  最低唤醒限制: {args.min_wake_limits}\n")
            f.write(f"  最高唤醒限制: {args.max_wake_limits}\n")
            f.write(f"  推荐模型数量: {args.top_n_models}\n\n")
            
            f.write("推荐模型列表:\n")
            f.write("-" * 80 + "\n")
            f.write(f"{'排名':<6}{'模型':<12}{'各类别唤醒次数':<30}{'有效总数':<10}{'原始总数':<10}\n")
            f.write("-" * 80 + "\n")
            
            for rank, model in enumerate(top_models, 1):
                class_str = str(model['class_totals'])
                f.write(f"{rank:<6}{model['name']:<40}{class_str:<40}{model['effective_total']:<10}{model['original_total']:<10}\n")
        
        print(f'\n推荐结果已保存至: {recommendation_file}')
    else:
        print('没有符合条件的模型!')

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='唤醒词检测和模型比较工具')
    
    # 唤醒配置参数
    parser.add_argument('-g', '--gain', type=float, default=0, help='音频增益 (dB)')
    parser.add_argument('-d', '--device', type=str, default='cuda:0', help='计算设备')
    parser.add_argument('-t', '--threshold', type=float, default=0.5, help='唤醒阈值')
    parser.add_argument('-fc', '--f_consecutive', type=int, default=3, help='连续激活帧数')
    parser.add_argument('-fd', '--f_cooldown', type=int, default=60, help='冷却时间帧数')
    parser.add_argument('-s', '--start_epoch', type=int, default=0, help='开始epoch')
    parser.add_argument('-e', '--end_epoch', type=int, default=1000, help='结束epoch')
    parser.add_argument('-sf', '--suffix', type=str, default='wav', choices=['wav', 'pcm'], help='音频文件后缀')
    parser.add_argument('--tag', type=str, default='set0917', help='标签名称')
    parser.add_argument('-i', '--input_dir', type=str, 
                       default='/datapool/deep_learning/userspace/zhangkanghao/data/projects/guoguang-series/testset/0917-set',
                       help='输入目录')
    parser.add_argument('-o', '--output_dir', type=str,
                       default='/datapool/deep_learning/userspace/zhangkanghao/data/projects/guoguang-series/trainset/error-wake',
                       help='输出目录')
    
    # 模型比较参数
    parser.add_argument('-emc', '--enable_model_comparison', action='store_true', default=True, help='是否启用模型比较')
    parser.add_argument('-tn', '--top_n_models', type=int, default=5, help='推荐前N个模型')
    parser.add_argument('-min', '--min_wake_limits', type=int, nargs='+', default=[80, 80, 80, 80, 80], 
                       help='每个类别的最低唤醒限制')
    parser.add_argument('-max', '--max_wake_limits', type=int, nargs='+', default=[100, 100, 100, 100, 100],
                       help='每个类别的最高唤醒限制')
    
    # 模型配置参数
    parser.add_argument('-c', '--conf', type=str, default='proj-guoguang-kws/confs/folax-v1.0.yaml', help='配置文件路径')
    
    # 输出选项参数
    parser.add_argument('-efo', '--enable_full_output', action='store_true', default=False, help='是否启用完整音频输出')
    parser.add_argument('-eso', '--enable_segment_output', action='store_true', default=False, help='是否启用分段音频输出')
    parser.add_argument('-pre', '--segment_pre_seconds', type=int, default=5, help='唤醒点前n秒')
    parser.add_argument('-post', '--segment_post_seconds', type=int, default=5, help='唤醒点后m秒')
    
    args = parser.parse_args()

    # debug
    args.gain = 0
    args.device = 'cuda:0'
    args.threshold = 0.5
    args.suffix = 'pcm'  # 'wav' or 'pcm'
    args.tag = 'set0819-NLPI'
    args.num_classes = 7
    args.model_dir = '/datapool/deep_learning/userspace/zhangkanghao/code/kws-shunwei/shunwei-normal/model/class7_model'
    args.input_dir = '/datapool/deep_learning/userspace/zhangkanghao/code/kws-shunwei/shunwei-normal/test/wake-0819/NLPI-seg'
    # args.input_dir = '/datapool/deep_learning/userspace/zhangkanghao/code/kws-shunwei/shunwei-normal/test/error-trail/LPI-seg'
    args.output_dir = '/mnt/raid2/userspace/zhangkanghao/data/projects/shunwei-normandy/trainset/error-wake'
    args.result_dir = '/datapool/deep_learning/userspace/zhangkanghao/code/kws-shunwei/shunwei-normal/test'

    # 模型比较参数
    args.enable_model_comparison = False 
    args.top_n_models = 10  # 推荐前N个模型
    args.min_wake_limits = [0, 0, 0, 0, 0, 0, 0]  # 每个类别的最低唤醒限制 
    args.max_wake_limits = [100, 100, 100, 100, 100, 100, 100]  # 每个类别的最高唤醒限制

    # 配置模型列表
    models = list(browse_dir(args.model_dir, 'pickle'))
    models.sort(key=lambda x: Path(x).stem.split('-')[1])
    models = [model for model in models if 'fuse' not in model and 'mat' not in model]
    models = models[444:]
    models = [
        'model/class7_model/model-2550000-fused.pickle',
    ]


    # 读取文件列表
    files = {item: sorted(list(browse_dir(os.path.join(args.input_dir, item), args.suffix))) for item in os.listdir(args.input_dir) if os.path.isdir(os.path.join(args.input_dir, item))}

    # 日志参数
    log_writer = open(f'{args.result_dir}/log-{args.tag}.csv', 'a')
    log_writer.write(f"model, {', '.join([Path(file).stem for file in files])}\n")
    
    # 模型比较数据存储
    all_model_results = []  # 存储所有模型的结果用于比较

    # 初始化模型
    model = MDTCSML(stack_num=4, stack_size=4, in_channels=64, res_channels=128, kernel_size=7, causal=True, num_classes=args.num_classes+1)
    model = model.to(args.device)
    model.eval()

    # 处理每个epoch的模型
    for path in models:
        success, result = process_model_epoch(model, path, args, files, log_writer)
        if not success:
            break
            
        # 存储模型结果用于比较
        if args.enable_model_comparison:
            # 计算每个类别的总唤醒次数，应用单文件上限
            class_totals = [0] * args.num_classes
            for scene, scene_counts in result['results'].items():
                for class_idx, count in enumerate(scene_counts):
                    # 应用单文件上限：每个文件的每个类别不超过max_wake_limits
                    capped_count = min(count, args.max_wake_limits[class_idx])
                    class_totals[class_idx] += capped_count
            
            all_model_results.append({
                'name': Path(path).stem,
                'class_totals': class_totals,
                'total_count': result['total_count'],
                'results': result['results']
            })

    log_writer.close()
    
    # 模型比较和筛选
    if args.enable_model_comparison and all_model_results:
        perform_model_comparison(all_model_results, args)
    
    print('Processing completed!')
