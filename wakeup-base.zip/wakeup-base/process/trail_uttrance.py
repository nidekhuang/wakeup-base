import os
import sys
import torch
import numpy as np
import soundfile as sf
from pathlib import Path
from tools.stft_istft import *
from network.mdtc import MDTCSML
from train.train_script_1mic import resume_model


def gen_target_file_list(target_dir, target_ext='.wav'):
    l = []
    for root, dirs, files in os.walk(target_dir, followlinks=True):
        for f in files:
            f = os.path.join(root, f)
            ext = os.path.splitext(f)[1]
            ext = ext.lower()
            if ext == target_ext and '.proc' not in f:
                l.append(f)
    return l

if __name__ == '__main__':
    # 配置参数
    hop_size = 320
    threshold = 0.5
    f_consecutive = 1  # 连续激活帧数
    f_cooldown = 60   # 冷却时间帧数
    num_classes = 7
    model_dir = 'model/class7_model'
    input_dir = 'test/wake-badcase'
    output_dir = '/datapool/deep_learning/userspace/zhangkanghao/data/projects/shunwei-normandy/trainset/error-wake'
    suffix = 'wav'  # 'wav' or 'pcm'
    type = 'badcase'
    
    # 输出选项
    enable_segment_output = False
    segment_pre_seconds = 5  # 唤醒点前n秒
    segment_post_seconds = 5  # 唤醒点后m秒
    enable_full_output = False

    # 创建输出目录
    os.makedirs(output_dir, exist_ok=True)
        
    net_work = MDTCSML(stack_num=4, stack_size=4, in_channels=64, res_channels=128, kernel_size=7, causal=True, num_classes=num_classes+1)
    net_work = net_work.to('cuda:0')
    net_work.eval()

    # models
    models = gen_target_file_list(model_dir, '.pickle')
    models.sort(key=lambda x: x.split('-')[1])
    models = models[71:]
    models = [
        'model/class7_model/model-2125000--118.7786205291748.pickle',
    ]

    # files
    if suffix == 'wav':
        files = gen_target_file_list(input_dir, '.wav')
    else:
        files = gen_target_file_list(input_dir, '.pcm')
    files.sort()

    # logs
    log_writer = open(f'{input_dir}/log-{type}.csv', 'a')
    log_writer.write(f"model, {', '.join([Path(file).stem for file in files])}\n")

    for model in models:
        model_name = Path(model).stem
        resume_model(net_work, Path(model).parent, Path(model).stem)
        results = []
        total_count = 0
        for file in files:
            # 读取音频文件
            if suffix == 'wav':
                mix, sr = sf.read(file)
            else:
                mix, sr = sf.read(file, channels=2, samplerate=16000, format='RAW', subtype='PCM_16')
            
            if len(mix.shape) == 1:
                mix = np.reshape(mix, [-1, 1])
                
            filename = Path(file).stem
            audio_outputs = []
            channel_counts = []
            channel_wake_frames = []
            
            for ch in range(mix.shape[1]):
                audio_ch = torch.from_numpy(mix[:, ch].astype(np.float32))
                with torch.no_grad():
                    audio_ch = audio_ch.unsqueeze(dim=0).to('cuda:0')
                    length = audio_ch.size(-1)
                    
                    # 长音频分段处理
                    if length > 16000 * 200:
                        outputs = []
                        hidden = None
                        for i in range(length // (16000 * 200) + 1):
                            chunk = audio_ch[..., i * 16000 * 200:(i + 1) * 16000 * 200]
                            if chunk.size(0) < 1:
                                break
                            logist, pinyin_logist, hidden, _, _, _, _ = net_work(chunk, hidden=hidden)
                            outputs.append(logist)
                        predictions = torch.cat(outputs, dim=1)
                    else:
                        predictions, _, _, _, _, _, _ = net_work(audio_ch)
                    scores, class_ids = (torch.softmax(predictions, dim=-1).squeeze()[:, 1:]).max(1)

                    frame_idx = 0
                    class_counts = [0] * num_classes  # 统计各类别唤醒次数
                    wake_frames = []
                    kws_marks = torch.zeros_like(audio_ch)
                    consecutive_count = 0
                    cooldown_frames = 0
                    
                    while frame_idx < scores.size(0):
                        # 冷却时间内跳过
                        if cooldown_frames > 0:
                            cooldown_frames -= 1
                            frame_idx += 1
                            continue
                            
                        if scores[frame_idx] > threshold:
                            consecutive_count += 1
                            if consecutive_count >= f_consecutive:
                                # 触发唤醒
                                current_class = class_ids[frame_idx].item()
                                kws_marks[:, min(frame_idx * hop_size, kws_marks.shape[1] - 1)] = 0.1 * (current_class + 1)
                                class_counts[current_class] += 1
                                total_count += 1
                                wake_frames.append(frame_idx)
                                
                                # 输出切片
                                if enable_segment_output:
                                    start_sample = max((frame_idx - segment_pre_seconds * sr // hop_size) * hop_size, 0)
                                    end_sample = min((frame_idx + segment_post_seconds * sr // hop_size) * hop_size, audio_ch.size(1))
                                    segment_audio = audio_ch[:, start_sample:end_sample].squeeze().detach().cpu().numpy()
                                    segment_path = os.path.join(output_dir, f'{model_name}_{filename}_ch{ch}_class{current_class}_frame{frame_idx}.wav')
                                    sf.write(segment_path, segment_audio, sr)
                                
                                # 设置冷却时间
                                cooldown_frames = f_cooldown
                                consecutive_count = 0
                        else:
                            consecutive_count = 0
                        
                        frame_idx += 1
                    
                channel_counts.append(class_counts)
                channel_wake_frames.append(wake_frames)
                
                min_len = min(kws_marks.shape[1], audio_ch.reshape(-1).shape[0])
                audio_outputs.append(audio_ch.reshape(-1)[:min_len])
                audio_outputs.append(kws_marks.reshape(-1)[:min_len])
            
            # 输出完整音频
            if enable_full_output:
                est = torch.stack(audio_outputs, dim=-1).detach().cpu().numpy()
                full_output_dir = os.path.join(input_dir, model_name)
                Path(full_output_dir).mkdir(parents=True, exist_ok=True)
                full_output_path = os.path.join(full_output_dir, f'{filename}.proc.wav')
                sf.write(full_output_path, est, sr)
            
            results.append(channel_counts)
            print(f'{model_name} - {filename}: {channel_counts} wakes detected')
            
        # 记录日志
        log_writer.write(f"{model_name},{results},total_count={total_count}\n")
        log_writer.flush()

    log_writer.close()
    print('Processing completed!')
