#!/usr/bin/env python3
# Copyright (c) 2021 Jingyong Hou (houjingyong@gmail.com)
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from typing import OrderedDict
import torch
import librosa
import soundfile as sf
import random
import numpy as np
import torch.nn as nn
import torch.nn.functional as F
import re
import os
import glob
from collections import defaultdict
# from tools.torch_stft import STFT
# from component.time_vad import TimeVad


def resume_model(net, models_path, device='cpu'):
    # if is_map_to_cpu or not torch.cuda.is_available():
    model_dict = torch.load(models_path, map_location=device)
    state_dict = model_dict['state_dict']
    for k, v in net.state_dict().items():
        if k.split('.')[0] == 'module':
            net_has_module = True
        else:
            net_has_module = False
        break
    dest_state_dict = OrderedDict()
    for k, v in state_dict.items():
        if k.split('.')[0] == 'module':
            ckpt_has_module = True
        else:
            ckpt_has_module = False
        if net_has_module == ckpt_has_module:
            dest_state_dict = state_dict
            break
        if ckpt_has_module:
            dest_state_dict[k.replace('module.', '')] = v
        else:
            dest_state_dict['module.{}'.format(k)] = v

    net.load_state_dict(dest_state_dict, False)
    step = model_dict['step']
    optim_state = model_dict['optimizer']
    print('finish to resume model {}.'.format(models_path))
    return step, optim_state

class STFT(torch.nn.Module):
    def __init__(self, win_len=1024, shift_len=512, window=None):
        super(STFT, self).__init__()
        if window is None:
            window = torch.from_numpy(np.sqrt(np.hanning(win_len).astype(np.float32)))
        self.win_len = win_len
        self.shift_len = shift_len
        self.window = window

    def transform(self, input_data):
        self.window = self.window.to(input_data.device)
        spec = torch.stft(input_data, n_fft=self.win_len, hop_length=self.shift_len, win_length=self.win_len, window=self.window, center=True, pad_mode='constant', return_complex=True)
        spec = torch.view_as_real(spec)
        return spec.permute(0, 2, 1, 3)

    def inverse(self, spec):
        self.window = self.window.to(spec.device)
        torch_wav = torch.istft(torch.view_as_complex(torch.permute(spec, [0, 2, 1, 3])), n_fft=self.win_len, hop_length=self.shift_len, win_length=self.win_len, window=self.window, center=True)
        return torch_wav

    def forward(self, input_data):
        stft_res = self.transform(input_data)
        reconstruction = self.inverse(stft_res)
        return reconstruction

class TimeVad(object):
    def __init__(self, shift=256):
        super(TimeVad, self).__init__()
        self.shift = shift

    def __frame__(self, in_wav):
        b, t = in_wav.size()
        padding_size = int(np.ceil(in_wav.shape[-1] / self.shift)) * self.shift - in_wav.shape[-1]
        if padding_size > 0:
            pad_wav = torch.cat([in_wav, torch.zeros([b, padding_size], device=in_wav.device)], dim=-1)
        else:
            pad_wav = torch.ones_like(in_wav) * in_wav
        frame_wav = pad_wav.reshape([b, -1, self.shift])
        return frame_wav

    def __call__(self, in_wav):
        frame_wav = self.__frame__(in_wav)
        pow = (frame_wav ** 2).sum(-1)
        pow_db = 10 * torch.log10(pow + 1e-7)
        threshold = pow_db[:, :20].amax(-1, keepdim=True) + 10
        # sorted, indices = torch.sort(pow_db, dim=-1)
        # mean_pow = sorted[:, -50:].mean(-1, keepdim=True)
        # threshold = mean_pow - 15
        frame_vad = torch.where(pow_db <= threshold, torch.zeros_like(pow_db),
                                torch.ones_like(pow_db)).unsqueeze(dim=-1)
        # in_wav为全0时，mean_pow为-70
        zero_check = torch.where(threshold < -60, torch.zeros_like(pow_db), torch.ones_like(pow_db))
        frame_vad = frame_vad * zero_check.unsqueeze(dim=-1)
        sample_vad = frame_vad.repeat(1, 1, self.shift).reshape(in_wav.shape[0], -1)[:, :in_wav.shape[-1]]
        return frame_vad, sample_vad

class CTC(torch.nn.Module):
    """CTC module"""
    def __init__(
        self,
        reduce: bool = True,
    ):
        """ Construct CTC module
        Args:
            odim: dimension of outputs
            encoder_output_size: number of encoder projection units
            dropout_rate: dropout rate (0.0 ~ 1.0)
            reduce: reduce the CTC loss into a scalar
        """
        super().__init__()

        reduction_type = "sum" if reduce else "none"
        self.ctc_loss = torch.nn.CTCLoss(reduction=reduction_type)

    def forward(self, ys_hat: torch.Tensor, hlens: torch.Tensor,
                ys_pad: torch.Tensor, ys_lens: torch.Tensor) -> torch.Tensor:
        """Calculate CTC loss.

        Args:
            hs_pad: batch of padded hidden state sequences (B, Tmax, D)
            hlens: batch of lengths of hidden state sequences (B)
            ys_pad: batch of padded character id sequence tensor (B, Lmax)
            ys_lens: batch of lengths of character sequence (B)
        """
        # ys_hat: (B, L, D) -> (L, B, D)
        ys_hat = ys_hat.transpose(0, 1)
        ys_hat = ys_hat.log_softmax(2)
        loss = self.ctc_loss(ys_hat, ys_pad, hlens, ys_lens)
        # Batch-size average
        loss = loss / ys_hat.size(1)
        return loss

    def softmax(self, hs_pad: torch.Tensor) -> torch.Tensor:
        return F.softmax(self.ctc_lo(hs_pad), dim=2)

    def log_softmax(self, hs_pad: torch.Tensor) -> torch.Tensor:
        """log_softmax of frame activations

        Args:
            Tensor hs_pad: 3d tensor (B, Tmax, eprojs)
        Returns:
            torch.Tensor: log softmax applied 3d tensor (B, Tmax, odim)
        """
        return F.log_softmax(self.ctc_lo(hs_pad), dim=2)

    def argmax(self, hs_pad: torch.Tensor) -> torch.Tensor:
        """argmax of frame activations

        Args:
            torch.Tensor hs_pad: 3d tensor (B, Tmax, eprojs)
        Returns:
            torch.Tensor: argmax applied 2d tensor (B, Tmax)
        """
        return torch.argmax(self.ctc_lo(hs_pad), dim=2)

class Fbank(nn.Module):
    def __init__(self, sample_rate=16000, filter_length=512, hop_length=256, n_mels=64):
        super(Fbank, self).__init__()
        self.stft = STFT(filter_length, hop_length)
        self.alpha = nn.Parameter(torch.FloatTensor(1, 257))
        nn.init.constant_(self.alpha, 3)
        # self.ln = nn.LayerNorm([5, 16])
        self.linear_to_mel_weight_matrix = torch.from_numpy(librosa.filters.mel(sr=sample_rate,
                                                                                n_fft=filter_length,
                                                                                n_mels=n_mels,
                                                                                fmin=20,
                                                                                fmax=8000,
                                                                                htk=True,
                                                                                norm=None).T.astype(np.float32))
    def spec_aug(self, spec, num_t_mask=2, num_f_mask=3, max_t=3, max_f=5):
        b, t, f, _ = spec.size()
        for i in range(b):
            if random.random() < 0.3:
                for j in range(num_t_mask):
                    start = random.randint(0, t - 1)
                    length = random.randint(1, max_t)
                    end = min(t, start + length)
                    spec[i, start:end] = 0

                for j in range(num_f_mask):
                    start = random.randint(0, f - 1)
                    length = random.randint(1, max_f)
                    end = min(f, start + end)
                    spec[i, :, start:end] = 0
        return spec


    def forward(self, input_waveform):
        with torch.no_grad():
            spec = self.stft.transform(input_waveform) # [1, 626, 257, 2]
            spec[:, :, 0, :] = 0
            # if self.training:
            #     spec = self.spec_aug(spec)
            mag = (spec ** 2).sum(-1).sqrt()
        abs_mel = torch.matmul(mag, self.linear_to_mel_weight_matrix.to(input_waveform.device))
        abs_mel = abs_mel + 1e-6
        log_mel = abs_mel.log()
        log_mel[log_mel < -6] = -6
        return log_mel, mag

class DSDilatedConv1d(nn.Module):
    """Dilated Depthwise-Separable Convolution"""
    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        kernel_size: int,
        dilation: int = 1,
        stride: int = 1,
        bias: bool = False,
    ):
        super(DSDilatedConv1d, self).__init__()
        self.receptive_fields = dilation * (kernel_size - 1)
        self.conv = nn.Conv1d(
            in_channels,
            in_channels,
            kernel_size,
            padding=0,
            dilation=dilation,
            stride=stride,
            groups=in_channels,
            bias=bias,
        )
        self.convbn = nn.BatchNorm1d(in_channels)
        self.pointwise = nn.Conv1d(in_channels,
                                   out_channels // 2,
                                   kernel_size=1,
                                   padding=0,
                                   dilation=1,
                                   bias=bias)
        self.pointwisebn = nn.BatchNorm1d(out_channels // 2)

    def forward(self, inputs: torch.Tensor):
        outputs = self.convbn(self.conv(inputs))
        outputs = self.pointwisebn(self.pointwise(outputs))
        return outputs

class TCNBlock(nn.Module):
    def __init__(
        self,
        in_channels: int,
        res_channels: int,
        kernel_size: int,
        dilation: int,
        causal: bool,
    ):
        super(TCNBlock, self).__init__()
        self.in_channels = in_channels
        self.res_channels = res_channels
        self.kernel_size = kernel_size
        self.dilation = dilation
        self.causal = causal
        self.receptive_fields = dilation * (kernel_size - 1)
        self.half_receptive_fields = self.receptive_fields // 2
        self.conv1 = DSDilatedConv1d(
            in_channels=in_channels,
            out_channels=res_channels,
            kernel_size=kernel_size,
            dilation=dilation,
        )
        self.prelu1 = nn.PReLU(res_channels // 2)

        self.conv2 = nn.Conv1d(in_channels=res_channels // 2,
                               out_channels=res_channels,
                               kernel_size=1)
        self.conv2bn = nn.BatchNorm1d(res_channels)
        self.prelu2 = nn.PReLU(res_channels)

    def forward(self, xs: torch.Tensor, xs_lens=None, cnn_cache=None, is_last_cache=False):
        if cnn_cache is None:
            # inputs = F.pad(xs, (self.receptive_fields, 0, 0, 0, 0, 0),
            #                 'constant')
            cnn_cache = torch.zeros([xs.shape[0], xs.shape[1], self.receptive_fields], dtype=xs.dtype, device=xs.device)
        inputs = torch.cat((cnn_cache, xs), dim=-1)
        if xs_lens is None or is_last_cache:
            new_cache = inputs[:, :, -self.receptive_fields:]
        else:
            new_cache = []
            for i, xs_len in enumerate(xs_lens):
                c = inputs[i:i+1, :, xs_len:xs_len+self.receptive_fields]
                new_cache.append(c)
            new_cache = torch.cat(new_cache, axis=0)
        # new_cache = inputs[:, :, -self.receptive_fields:]

        outputs1 = self.prelu1(self.conv1(inputs))
        outputs2 = self.conv2(outputs1)
        inputs = inputs[:, :, self.receptive_fields:]
        if self.in_channels == self.res_channels:
            res_out = self.prelu2(self.conv2bn(outputs2) + inputs)
        else:
            res_out = self.prelu2(self.conv2bn(outputs2))
        return res_out, new_cache.detach(), [outputs1, outputs2, res_out]

    def fuse_module(self):
        x = torch.randn(1, self.in_channels, 100)
        y1 = self(x)[0]
        torch.quantization.fuse_modules(self, [
            ['conv1.conv', 'conv1.convbn'],
            ['conv1.pointwise', 'conv1.pointwisebn'],
            ['conv2', 'conv2bn']
            ],
            inplace=True)
        y2 = self(x)[0]
        e = torch.abs(y1 - y2).max().item()
        print(f"融合误差: {e:.10f}")

    # def fuse_module(self):
    #     w, b = fuse_conv_bn(self.conv1.conv, self.conv1.convbn)
    #     x = torch.randn(1, w.shape[0], 100)
    #     new_conv = nn.Conv1d(
    #         in_channels=self.conv1.conv.in_channels,
    #         out_channels=self.conv1.conv.out_channels,
    #         kernel_size=self.conv1.conv.kernel_size,
    #         stride=self.conv1.conv.stride,
    #         padding=self.conv1.conv.padding,
    #         dilation=self.conv1.conv.dilation,
    #         groups=self.conv1.conv.groups,
    #         bias=True  # 确保有偏置
    #     )
    #     with torch.no_grad():
    #         y1 = self.conv1.convbn(self.conv1.conv(x))
    #         new_conv.weight.copy_(w)
    #         new_conv.bias.copy_(b)
    #         self.conv1.conv = new_conv
    #         self.conv1.convbn = nn.Identity()  # 设置为恒等层
    #         y2 = self.conv1.conv(x)
    #         e = torch.abs(y1 - y2).max().item()
    #         print(f"融合误差: {e:.10f}")


    #     w, b = fuse_conv_bn(self.conv1.pointwise, self.conv1.pointwisebn)
    #     x = torch.randn(1, w.shape[1], 100)
    #     new_convp = nn.Conv1d(
    #         in_channels=self.conv1.pointwise.in_channels,
    #         out_channels=self.conv1.pointwise.out_channels,
    #         kernel_size=self.conv1.pointwise.kernel_size,
    #         stride=self.conv1.pointwise.stride,
    #         padding=self.conv1.pointwise.padding,
    #         dilation=self.conv1.pointwise.dilation,
    #         groups=self.conv1.pointwise.groups,
    #         bias=True  # 确保有偏置
    #     )
    #     with torch.no_grad():
    #         y1 = self.conv1.pointwisebn(self.conv1.pointwise(x))
    #         new_convp.weight.copy_(w)
    #         new_convp.bias.copy_(b)
    #         self.conv1.pointwise = new_convp
    #         self.conv1.pointwisebn = nn.Identity()  # 设置为恒等层
    #         y2 = self.conv1.pointwisebn(self.conv1.pointwise(x))
    #         e = torch.abs(y1 - y2).max().item()
    #         print(f"融合误差: {e:.6f}")

    #     w, b = fuse_conv_bn(self.conv2, self.conv2bn)
    #     x = torch.randn(1, w.shape[1], 100)
    #     with torch.no_grad():
    #         y1 = self.conv2bn(self.conv2(x))
    #         new_conv2 = nn.Conv1d(
    #             in_channels=self.conv2.in_channels,
    #             out_channels=self.conv2.out_channels,
    #             kernel_size=self.conv2.kernel_size,
    #             stride=self.conv2.stride,
    #             padding=self.conv2.padding,
    #             dilation=self.conv2.dilation,
    #             groups=self.conv2.groups,
    #             bias=True  # 确保有偏置
    #         )
    #         new_conv2.weight.copy_(w)
    #         new_conv2.bias.copy_(b)
    #         self.conv2 = new_conv2
    #         self.conv2bn = nn.Identity()  # 设置为恒等层
    #         y2 = self.conv2bn(self.conv2(x))
    #         e = torch.abs(y1 - y2).max().item()
    #         print(f"融合误差: {e:.6f}")

    #     return

class TCNStack(nn.Module):
    def __init__(
        self,
        in_channels: int,
        stack_num: int,
        res_channels: int,
        kernel_size: int,
        causal: bool,
    ):
        super(TCNStack, self).__init__()
        assert causal is True
        self.in_channels = in_channels
        self.stack_num = stack_num
        # self.stack_size = stack_size
        self.res_channels = res_channels
        self.kernel_size = kernel_size
        self.causal = causal
        self.res_blocks = self.stack_tcn_blocks()
        self.receptive_fields = self.calculate_receptive_fields()
        self.res_blocks = nn.Sequential(*self.res_blocks)

    def calculate_receptive_fields(self):
        receptive_fields = 0
        for block in self.res_blocks:
            receptive_fields += block.receptive_fields
        return receptive_fields

    def build_dilations(self):
        dilations = []
        # for s in range(0, self.stack_size):
        for l in range(0, self.stack_num):
            dilations.append(2**l)
        return dilations

    def stack_tcn_blocks(self):
        dilations = self.build_dilations()
        res_blocks = nn.ModuleList()

        res_blocks.append(
            TCNBlock(
                self.in_channels,
                self.res_channels,
                self.kernel_size,
                dilations[0],
                self.causal,
            ))
        for dilation in dilations[1:]:
            res_blocks.append(
                TCNBlock(
                    self.res_channels,
                    self.res_channels,
                    self.kernel_size,
                    dilation,
                    self.causal,
                ))
        return res_blocks

    def forward(self, xs: torch.Tensor, xs_lens=None, cnn_caches=None, is_last_cache=False):
        new_caches = []
        out_list_for_loss = []
        for block, cnn_cache in zip(self.res_blocks, cnn_caches):
            xs, new_cache, out_l = block(xs, xs_lens, cnn_cache, is_last_cache=is_last_cache)
            new_caches.append(new_cache)
            out_list_for_loss += out_l
        return xs, new_caches, out_list_for_loss

    def fuse_module(self,):
        for layer in self.res_blocks:
            layer.fuse_module()

class MDTCSML(nn.Module):
    """Multi-scale Depthwise Temporal Convolution (MDTC).
    In MDTC, stacked depthwise one-dimensional (1-D) convolution with
    dilated connections is adopted to efficiently model long-range
    dependency of speech. With a large receptive field while
    keeping a small number of model parameters, the structure
    can model temporal context of speech effectively. It aslo
    extracts multi-scale features from different hidden layers
    of MDTC with different receptive fields.
    """
    def __init__(
        self,
        stack_num: int,
        stack_size: int,
        in_channels: int,
        res_channels: int,
        kernel_size: int,
        causal: bool,
        shift=320,
        num_classes=7
    ):
        super(MDTCSML, self).__init__()
        self.layer_norm = nn.LayerNorm([5, 2])
        self.kernel_size = kernel_size
        self.causal = causal
        self.preprocessor = TCNBlock(in_channels,
                                     res_channels,
                                     kernel_size,
                                     dilation=1,
                                     causal=causal)
        self.prelu = nn.PReLU(res_channels)
        self.blocks = nn.ModuleList()
        self.receptive_fields = []
        self.receptive_fields.append(self.preprocessor.receptive_fields)
        for _ in range(stack_num):
            self.blocks.append(
                TCNStack(res_channels, stack_size, res_channels,
                         kernel_size, causal))
            self.receptive_fields.append(self.blocks[-1].receptive_fields)
        self.pooling_cnn = nn.Conv2d(in_channels=stack_num, out_channels=1, kernel_size=(1, 1), bias=False)
        self.pooling_relu = nn.PReLU(1)
        self.stack_num = stack_num
        self.stack_size = stack_size

        self.fbank = Fbank(sample_rate=16000, filter_length=shift * 2, hop_length=shift, n_mels=64)
        self.time_vad = TimeVad(256)
        vocab_size = 410 # 拼音分类
        self.pinyin_fc = torch.nn.Linear(res_channels, vocab_size)
        self.class_fc = torch.nn.Linear(res_channels, num_classes)
        self.ctc = CTC()
        self.drop_out = nn.Dropout(p=0.1)
        self.shift = shift

    def forward(self, wav, kw_target=None, ckw_target=None, real_frames=None, label_frames=None, ckw_len=None, clean_speech=None, hidden=None, custom_in=None):
        if hidden is None:
            hidden = [None for _ in range(self.stack_size * self.stack_num + 1)]
        else:
            if hidden[0].shape[0] >= wav.shape[0]:
                b = wav.size(0)
                h_l = []
                for h in hidden:
                    h_l.append(h[:b])
                hidden = h_l
            else:
                hidden = [None for _ in range(self.stack_size * self.stack_num + 1)]

        xs, mag = self.fbank(wav)

        b, t, f = xs.size()
        if random.random() < 0.5 and self.training:
            is_last_cache = True
        else:
            is_last_cache = False
        outputs = xs.transpose(1, 2)
        outputs_list = []
        outputs_list_for_loss = []
        outputs_cache_list  = []
        outputs, new_cache,  o_l_1= self.preprocessor(outputs, real_frames, hidden[0], is_last_cache=is_last_cache)
        outputs_list_for_loss += o_l_1
        outputs = self.prelu(outputs)
        outputs_list_for_loss.append(outputs)
        outputs_pre = outputs
        outputs_cache_list.append(new_cache)
        for i in range(len(self.blocks)):
            outputs, new_caches, o_l_tmp = self.blocks[i](outputs, real_frames, hidden[1+i*self.stack_size: 1 +(i+1)*self.stack_size], is_last_cache=is_last_cache)
            outputs_list_for_loss += o_l_tmp
            outputs_list.append(outputs)
            outputs_cache_list += new_caches

        outputs = sum(outputs_list)
        outputs = outputs.transpose(1, 2)
        pinyin_logist = self.pinyin_fc(outputs_list[1].transpose(1, 2))
        logist = self.class_fc(outputs)

        return logist, mag

    def fuse_module(self, ):
        self.preprocessor.fuse_module()
        for i in range(len(self.blocks)):
            self.blocks[i].fuse_module()
        print()

def fuse_conv_bn(conv, bn):
    conv_weight = conv.weight.data.clone()
    if conv.bias is None:
        conv_bias = torch.zeros(conv_weight.shape[0], dtype=torch.float32)
    else:
        conv_bias = conv.bias.data.clone()

    # 2. 获取BN参数
    bn_gamma = bn.weight.data.clone()
    bn_beta = bn.bias.data.clone()
    bn_mean = bn.running_mean.data.clone()
    bn_var = bn.running_var.data.clone()
    bn_eps = bn.eps

    # 3. 计算融合参数
    std = torch.sqrt(bn_var + bn_eps)
    scale_factor = bn_gamma / std

    # 5. 计算融合后的权重和偏置
    fused_weight = conv_weight * scale_factor.reshape([-1] + [1] * (len(conv_weight.shape) - 1))
    fused_bias = bn_beta + (conv_bias - bn_mean) * scale_factor

    return fused_weight, fused_bias



def simulate_known_keyword_files(network, file_paths, threshold=0.5, save_proc=True):
    """
    仿真已知命令词的文件列表，每个文件对应一个特定的命令词

    Args:
        network: 训练好的神经网络模型
        file_paths: 文件路径列表，格式为 [(path, expected_keyword_id), ...]
        threshold: 检测阈值
        save_proc: 是否保存处理后的音频文件
    """

    results = []
    for i, (file_path, expected_id) in enumerate(file_paths):
        print(f"\n处理文件 {i+1}/{len(file_paths)}: {file_path}")
        data, _ = sf.read(file_path)

        with torch.no_grad():
            data_in = torch.from_numpy(data.astype(np.float32)).reshape(1, -1)
            est_kws = torch.zeros_like(data_in)
            est_logist = network(data_in)
            est_logist, idx = (torch.softmax(est_logist, dim=-1).squeeze()[:, 1:]).max(1)

            count = 0
            k = 0
            while k < est_logist.size(0):
                if est_logist[k] > threshold and idx[k] == expected_id:
                    est_kws[:, k * 320] = 0.1 * (idx[k] + 1)
                    count += 1
                    k += 40
                else:
                    k += 1

            print(f"预期命令词ID: {expected_id}, 检测到次数: {count}")
            results.append((file_path, expected_id, count))

            if save_proc:
                output_path = file_path.replace('.wav', '.proc.wav')
                sf.write(output_path, torch.cat([data_in, est_kws], dim=0).T, 16000)

    return results


def simulate_single_file_all_keywords(network, file_path, threshold=0.5, n_keywords=6):
    """
    仿真单个文件，统计所有可能的命令词次数

    Args:
        network: 训练好的神经网络模型
        file_path: 音频文件路径
        threshold: 检测阈值
        n_keywords: 命令词总数（不包括背景类）

    Returns:
        dict: 包含各命令词统计信息的字典
    """


    print(f"\n分析文件: {file_path}")
    data, _ = sf.read(file_path)

    # 初始化计数器
    keyword_counts = [0] * n_keywords  # 索引0对应命令词ID1，以此类推
    total_detections = 0
    detection_details = []

    with torch.no_grad():
        data_in = torch.from_numpy(data.astype(np.float32)).reshape(1, -1)
        est_logist = network(data_in)
        est_logist, idx = (torch.softmax(est_logist, dim=-1).squeeze()[:, 1:]).max(1)

        k = 0
        while k < est_logist.size(0):
            if est_logist[k] > threshold:
                keyword_id = idx[k].item()  # 命令词ID (0-based)
                actual_cmd_id = keyword_id + 1  # 实际命令词ID (1-based)

                # 计算时间信息
                time_sec = k * 0.020  # 假设每帧20ms
                t_min = int(time_sec // 60)
                t_sec = int(time_sec % 60)
                t_msec = int((time_sec - int(time_sec)) * 1000)

                # 统计
                keyword_counts[keyword_id] += 1
                total_detections += 1

                detection_details.append({
                    'frame': k,
                    'time': f"{t_min:02d}:{t_sec:02d}.{t_msec:03d}",
                    'keyword_id': actual_cmd_id,
                    'probability': est_logist[k].item()
                })

                if 0:
                    print(f"检测到命令词 ID={actual_cmd_id}, 时间={t_min:02d}:{t_sec:02d}.{t_msec:03d}, "
                        f"帧={k:5d}, 概率={est_logist[k].item():.4f}")

                k += 40  # 跳过一段时间避免重复检测
            else:
                k += 1

    # 打印统计结果
    print(f"\n=== {file_path} 统计结果 ===")
    for i in range(n_keywords):
        if keyword_counts[i] > 0:
            print(f"命令词 ID {i+1}: {keyword_counts[i]} 次")
    print(f"总检测次数: {total_detections}")
    print("=" * 50)

    return {
        'file_path': file_path,
        'keyword_counts': keyword_counts,
        'total_detections': total_detections,
        'detection_details': detection_details
    }


def simulate_folder_streaming(network, folder_list, frame_length=320, hop_length=320,
                            threshold=0.5, n_keywords=6):
    """
    按文件夹进行流式仿真，每个文件独立处理，简单后处理逻辑

    Args:
        network: 训练好的神经网络模型
        folder_list: 文件夹路径列表
        frame_length: 每帧样本数 (320 for 20ms at 16kHz)
        hop_length: 帧间跳跃样本数
        threshold: 检测阈值
        n_keywords: 命令词总数（不包括背景类）

    Returns:
        dict: 统计结果
    """
    import os
    import glob
    from collections import defaultdict

    # 总统计
    total_stats = {
        'total_files': 0,
        'total_wakeups': 0,
        'keyword_stats': defaultdict(int),  # 每个命令词的唤醒次数统计
        'detailed_results': []
    }

    print("\n=== 文件夹流式仿真开始 ===")

    for folder_path in folder_list:
        if not os.path.exists(folder_path):
            print(f"警告: 文件夹不存在: {folder_path}")
            continue

        print(f"\n处理文件夹: {folder_path}")

        # 查找所有.wav文件
        wav_files = glob.glob(os.path.join(folder_path, "*.pcm"))
        wav_files.sort()  # 按文件名排序

        if not wav_files:
            print(f"  未找到.wav文件")
            continue

        print(f"  找到 {len(wav_files)} 个.wav文件")

        # 处理每个文件
        for file_path in wav_files:
            try:
                result = _simulate_single_file_streaming(
                    network, file_path, frame_length, hop_length,
                    threshold, n_keywords
                )

                total_stats['total_files'] += 1
                total_stats['total_wakeups'] += result['wakeup_count']

                # 统计每个命令词
                if result['wakeup_keyword_id'] > 0:
                    total_stats['keyword_stats'][result['wakeup_keyword_id']] += 1

                total_stats['detailed_results'].append(result)

            except Exception as e:
                print(f"    处理文件 {os.path.basename(file_path)} 时出错: {e}")
                continue

    # 打印总结统计
    _print_folder_simulation_summary(total_stats)

    return total_stats


def _simulate_single_file_streaming(network, file_path, frame_length, hop_length,
                                   threshold, n_keywords):
    """
    对单个文件进行流式处理仿真，简单的后处理逻辑
    """
    import os
    import re

    filename = os.path.basename(file_path)
    print(f"    处理文件: {filename}")

    # 解析文件名获取期望的命令词ID
    # 格式: 000_00m17s040ms_1.wav -> expected_keyword_id = 1
    expected_keyword_id = _parse_filename_keyword_id(filename)

    # 读取音频文件
    try:
        data, sr = sf.read(file_path)
    except Exception as e:
        print(f"      读取音频失败: {e}")
        return {
            'file_path': file_path,
            'filename': filename,
            'expected_keyword_id': expected_keyword_id,
            'wakeup_count': 0,
            'wakeup_keyword_id': 0,
            'wakeup_details': [],
            'error': str(e)
        }

    if len(data) == 0:
        print(f"      音频文件为空")
        return {
            'file_path': file_path,
            'filename': filename,
            'expected_keyword_id': expected_keyword_id,
            'wakeup_count': 0,
            'wakeup_keyword_id': 0,
            'wakeup_details': [],
            'error': 'Empty audio file'
        }

    # 检查音频通道数
    if len(data.shape) == 1:
        # 单通道音频
        num_channels = 1
        print(f"      单通道音频")
        data = data.reshape(-1, 1)  # 转换为 (samples, 1) 格式
    else:
        # 多通道音频
        num_channels = data.shape[1]
        if num_channels > 2:
            print(f"      警告: 音频有 {num_channels} 个通道，只处理前2个通道")
            data = data[:, :2]
            num_channels = 2
        print(f"      {num_channels} 通道音频")

    print(f"      音频信息: {data.shape[0]} samples, {num_channels} channels, {sr} Hz")

    # 模拟简单的唤醒检测状态变量
    is_wake_up_before = False  # 是否已经唤醒过
    frame_no = 0  # 当前帧号
    wake_count = 0  # 唤醒次数
    wakeup_details = []  # 详细唤醒信息
    wakeup_keyword_id = 0  # 最终唤醒的命令词ID
    wakeup_channel = 0  # 触发唤醒的通道
    skip_frames = 0  # 需要跳过的帧数

    # 分别处理每个通道
    channel_results = []

    for channel_idx in range(num_channels):
        print(f"      处理通道 {channel_idx}")

        # 提取单通道数据
        if num_channels == 1:
            channel_data = data[:, 0]
        else:
            channel_data = data[:, channel_idx]

        data_tensor = torch.from_numpy(channel_data.astype(np.float32)).reshape(1, -1)

        # 运行模型获取全部输出
        with torch.no_grad():
            logits, mag = network(data_tensor)  # [1, T, n_classes]
            probs = torch.softmax(logits, dim=-1).squeeze(0)  # [T, n_classes]

            # 排除背景类，只考虑命令词类别
            keyword_probs = probs[:, 1:]  # [T, n_keywords]
            max_scores, max_ids = keyword_probs.max(dim=1)  # [T], [T]

        channel_results.append({
            'channel': channel_idx,
            'max_scores': max_scores,
            'max_ids': max_ids,
            'magnitude': mag
        })

    # 逐帧处理 - 比较所有通道的结果，简单的后处理方式
    total_frames = channel_results[0]['max_scores'].size(0)

    frame_idx = 0
    mag_cum = []
    for ch_idx, ch_result in enumerate(channel_results):
        ch_mag = ch_result['magnitude'][0, :, :].sum(1)
        mag_cum.append(torch.cumsum(ch_mag, dim=0))

    while frame_idx < total_frames and not is_wake_up_before:
        frame_no = frame_idx + 1

        # 如果在跳过期间，直接跳过
        if skip_frames > 0:
            skip_frames -= 1
            frame_idx += 1
            continue

        # 比较所有通道在当前帧的结果，选择分数最高的通道
        best_score = -1
        best_channel = 0
        best_keyword_id = 0

        # for ch_idx, ch_result in enumerate(channel_results):
        #     ch_score = ch_result['max_scores'][frame_idx].item()
        #     ch_id = ch_result['max_ids'][frame_idx].item()

        #     if ch_score > best_score:
        #         best_score = ch_score
        #         best_channel = ch_idx
        #         best_keyword_id = ch_id
        min_cum_mag = np.inf
        best_score_mag = -1
        best_channel_mag = 0
        best_keyword_id_mag = 0
        for ch_idx, ch_result in enumerate(channel_results):
            ch_score = ch_result['max_scores'][frame_idx].item()
            ch_id = ch_result['max_ids'][frame_idx].item()
            if mag_cum[ch_idx][frame_idx] < min_cum_mag:
                min_cum_mag = mag_cum[ch_idx][frame_idx]
                best_score_mag = ch_score
                best_channel_mag = ch_idx
                best_keyword_id_mag = ch_id
            # if ch_score > best_score:
            #     best_score = ch_score
            #     best_channel = ch_idx
            #     best_keyword_id = ch_id

        # 使用最佳通道的结果作为当前帧的结果
        cur_score = best_score_mag
        max_score_id = best_keyword_id_mag
        active_channel = best_channel_mag

        # if cur_score < threshold and best_score > threshold:
        #     cur_score = best_score
        #     max_score_id = best_keyword_id
        #     active_channel = best_channel

        # 简单的检测逻辑：分数超过阈值就记录
        if cur_score > threshold:
            # 触发唤醒
            wake_count = 1
            wakeup_keyword_id = max_score_id + 1  # 转换为1-based ID
            wakeup_channel = active_channel

            # 计算时间信息
            time_sec = frame_idx * 0.020  # 每帧20ms
            t_min = int(time_sec // 60)
            t_sec = int(time_sec % 60)
            t_msec = int((time_sec - int(time_sec)) * 1000)

            wakeup_info = {
                'frame_no': frame_no,
                'time': f"{t_min:02d}m{t_sec:02d}s{t_msec:03d}ms",
                'keyword_id': wakeup_keyword_id,
                'score': cur_score,
                'count': 1,
                'channel': wakeup_channel
            }
            wakeup_details.append(wakeup_info)

            if num_channels == 1:
                print(f"      唤醒! 帧={frame_no:4d}, 时间={wakeup_info['time']}, "
                      f"命令词ID={wakeup_keyword_id}, "
                      f"分数={cur_score:.4f}")
            else:
                print(f"      唤醒! 帧={frame_no:4d}, 时间={wakeup_info['time']}, "
                      f"命令词ID={wakeup_keyword_id}, 通道={wakeup_channel}, "
                      f"分数={cur_score:.4f}")

            # 设置跳过40帧 + 标记已唤醒
            skip_frames = 40
            is_wake_up_before = True

        frame_idx += 1

    # 验证结果
    is_correct = (wakeup_keyword_id == expected_keyword_id) if wakeup_keyword_id > 0 else False

    if wakeup_keyword_id == 0:
        print(f"      未检测到唤醒 (期望: {expected_keyword_id})")
    elif is_correct:
        pass
        # if num_channels == 1:
        #     print(f"      ✓ 正确唤醒: {wakeup_keyword_id}")
        # else:
        #     print(f"      ✓ 正确唤醒: {wakeup_keyword_id} (通道: {wakeup_channel})")
    else:
        if num_channels == 1:
            print(f"      ✗ 错误唤醒: {wakeup_keyword_id} (期望: {expected_keyword_id})")
        else:
            print(f"      ✗ 错误唤醒: {wakeup_keyword_id} (期望: {expected_keyword_id}, 通道: {wakeup_channel})")

    return {
        'file_path': file_path,
        'filename': filename,
        'expected_keyword_id': expected_keyword_id,
        'wakeup_count': wake_count,
        'wakeup_keyword_id': wakeup_keyword_id,
        'wakeup_channel': wakeup_channel,
        'num_channels': num_channels,
        'wakeup_details': wakeup_details,
        'is_correct': is_correct,
        'total_frames': total_frames
    }


def _parse_filename_keyword_id(filename):
    """
    从文件名解析期望的命令词ID
    文件名格式: 000_00m17s040ms_1.wav -> 1
    """
    try:
        # 使用正则表达式提取最后一个下划线后的数字
        match = re.search(r'_(\d+)\.wav$', filename)
        if match:
            return int(match.group(1))
        else:
            print(f"      警告: 无法从文件名 '{filename}' 解析命令词ID")
            return 0
    except Exception as e:
        print(f"      解析文件名出错: {e}")
        return 0


def _mode_fast_best_id(freq):
    """
    模拟C++的mode_fast_bestId函数
    找到累积次数最多的命令词ID
    """
    best_id = 0
    best_count = 0
    for i in range(len(freq)):
        if freq[i] > best_count:
            best_count = freq[i]
            best_id = i
    return best_id


def _print_folder_simulation_summary(stats):
    """
    打印文件夹仿真的总结统计
    """
    print("\n" + "="*60)
    print("文件夹仿真总结统计")
    print("="*60)

    print(f"总处理文件数: {stats['total_files']}")
    print(f"总唤醒次数: {stats['total_wakeups']}")

    if stats['total_files'] > 0:
        accuracy = sum(1 for r in stats['detailed_results']
                      if r.get('is_correct', False)) / stats['total_files']
        print(f"准确率: {accuracy:.2%}")

    print(f"\n各命令词唤醒统计:")
    for keyword_id in sorted(stats['keyword_stats'].keys()):
        count = stats['keyword_stats'][keyword_id]
        print(f"  命令词 ID {keyword_id}: {count} 次")

    # 通道统计
    channel_stats = defaultdict(int)
    single_channel_count = 0
    multi_channel_count = 0

    wakeup_results = [r for r in stats['detailed_results'] if r['wakeup_keyword_id'] > 0]
    for result in wakeup_results:
        if 'num_channels' in result and result['num_channels'] == 1:
            single_channel_count += 1
        elif 'wakeup_channel' in result:
            channel_stats[result['wakeup_channel']] += 1
            multi_channel_count += 1

    if single_channel_count > 0 or multi_channel_count > 0:
        print(f"\n通道统计:")
        if single_channel_count > 0:
            percentage = single_channel_count / len(wakeup_results) * 100 if len(wakeup_results) > 0 else 0
            print(f"  单通道文件: {single_channel_count} 次 ({percentage:.1f}%)")

        if multi_channel_count > 0:
            print(f"  多通道文件:")
            for channel in sorted(channel_stats.keys()):
                count = channel_stats[channel]
                percentage = count / len(wakeup_results) * 100 if len(wakeup_results) > 0 else 0
                print(f"    通道 {channel}: {count} 次 ({percentage:.1f}%)")

    # 错误分析
    errors = [r for r in stats['detailed_results']
             if not r.get('is_correct', False) and r['wakeup_keyword_id'] > 0]
    if errors:
        print(f"\n错误检测分析 ({len(errors)} 个):")
        error_stats = defaultdict(lambda: defaultdict(int))
        for error in errors:
            expected = error['expected_keyword_id']
            detected = error['wakeup_keyword_id']
            error_stats[expected][detected] += 1

        for expected in sorted(error_stats.keys()):
            for detected in sorted(error_stats[expected].keys()):
                count = error_stats[expected][detected]
                print(f"  期望{expected}->检测{detected}: {count}次")

    # 未检测文件
    no_detection = [r for r in stats['detailed_results']
                   if r['wakeup_keyword_id'] == 0]
    if no_detection:
        print(f"\n未检测到唤醒的文件 ({len(no_detection)} 个):")
        for r in no_detection[:10]:  # 只显示前10个
            print(f"  {r['filename']} (期望: {r['expected_keyword_id']})")
        if len(no_detection) > 10:
            print(f"  ... 还有 {len(no_detection) - 10} 个文件")

    print("="*60)


if __name__ == '__main__':
    THRES_HOLD = 0.5

    # 初始化网络
    net_work = MDTCSML(stack_num=4, stack_size=4, in_channels=64, res_channels=128, kernel_size=7, causal=True, num_classes=8)
    resume_model(net_work, 'model/class7_model/model-2125000--118.7786205291748.pickle')
    net_work.eval()
    # 融合模型并重复测试（原有功能）
    print("\n\n=== 融合模型测试 ===")
    net_work.fuse_module()
    net_work.eval()
    # torch.save({'state_dict': net_work.state_dict()}, './model/class7_model/model-2125000--118.7786205291748_fuse.pickle')

    if 0:
        # 方式1: 仿真已知命令词的文件（原有功能）
        print("=== 方式1: 仿真已知命令词文件 ===")
        known_keyword_files = [
            ('./wind.wav', 0),
            # ('./小溪小溪.wav', 0),
            # ('./下一首.wav', 1),
            # ('./开始拍照.wav', 2),
            # ('./开始录像.wav', 3),
            # ('./结束录像.wav', 4),
            # ('./帮我看看.wav', 5),
        ]
        print("融合模型 - 已知命令词文件测试:")
        results_known = simulate_known_keyword_files(net_work, known_keyword_files, THRES_HOLD)

    if 0:
        # 方式2: 仿真单个文件的所有命令词统计
        print("\n\n=== 方式2: 单文件全命令词统计 ===")
        test_files = [
            './shunwei-LPI_newapp_wind3.5m-1-0818-ch3.wav',
        ]
        all_results = []
        print("\n融合模型 - 单文件全命令词统计:")
        for file_path in test_files:
            try:
                result = simulate_single_file_all_keywords(net_work, file_path, THRES_HOLD, n_keywords=6)
                all_results.append(result)
            except Exception as e:
                print(f"处理文件 {file_path} 时出错: {e}")

    if 1:
        # 方式3: 新增的文件夹流式仿真模式
        print("\n\n=== 方式3: 文件夹流式仿真 ===")

        # 示例文件夹列表 - 请根据实际情况修改
        folder_list = [
            # 'C:\\Users\\lenovo_rh\\Downloads\\V5.2.53-LPI-kws-1-60\\simulation_dm\\舜为-唤醒词-50pcs-风噪4m-2mic_0606_kws_out_multi\\2mic',  # 命令词1的测试文件夹
            'test/wake-0819/LPI-seg/office/pcm'
        ]

        print("融合模型 - 文件夹流式仿真:")
        try:
            results_folder = simulate_folder_streaming(
                network=net_work,
                folder_list=folder_list,
                frame_length=320,          # 每帧样本数 (20ms at 16kHz)
                hop_length=320,           # 帧间跳跃
                threshold=THRES_HOLD,     # 检测阈值
                n_keywords=7             # 命令词总数（1-6）
            )

            print(f"\n文件夹仿真完成，共处理 {results_folder['total_files']} 个文件")

        except Exception as e:
            print(f"文件夹仿真出错: {e}")
            import traceback
            traceback.print_exc()