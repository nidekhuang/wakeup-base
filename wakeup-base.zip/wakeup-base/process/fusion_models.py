import os
import re
import json
import argparse
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Tuple

import torch

def _strip_module_prefix(state: Dict[str, torch.Tensor]) -> Dict[str, torch.Tensor]:
    """去除参数名中的 'module.' 前缀（如存在）"""
    if not state:
        return state
    has_prefix = all(k.startswith("module.") for k in state.keys())
    if has_prefix:
        return {k[len("module."):]: v for k, v in state.items()}
    return state


def _extract_state_dict(ckpt_obj) -> Dict[str, torch.Tensor]:
    """
    从多种常见 checkpoint 结构中提取 state_dict。
    支持：
    - 直接是 OrderedDict[str, Tensor]
    - 包含以下字段之一：'state_dict', 'model', 'net', 'model_state_dict', 'ema_state_dict', 'ema_model'
    """
    if isinstance(ckpt_obj, dict):
        # 可能直接是 state_dict
        if ckpt_obj and all(isinstance(k, str) for k in ckpt_obj.keys()) and any(
            isinstance(v, torch.Tensor) for v in ckpt_obj.values()
        ):
            return _strip_module_prefix(ckpt_obj)

        # 常见包装键
        candidates = [
            "ema_state_dict", "state_dict", "model", "net", "model_state_dict", "ema_model"
        ]
        for k in candidates:
            sd = ckpt_obj.get(k)
            if isinstance(sd, dict):
                if sd and all(isinstance(kk, str) for kk in sd.keys()):
                    if any(isinstance(v, torch.Tensor) for v in sd.values()):
                        return _strip_module_prefix(sd)
    # 兜底：返回空
    return {}


def _replace_state_dict_in_ckpt(ckpt_obj, fused: Dict[str, torch.Tensor]):
    """
    将融合后的 state_dict 写回到原 checkpoint 对象中，尽量保持原结构。
    写回顺序：
    1) 若存在 'state_dict'，优先替换；
    2) 其次 'model' 或 'net'；
    3) 其次 'model_state_dict'；
    4) 若顶层就是 dict[str, Tensor]，则直接替换为 fused。
    返回替换后的对象。
    """
    if isinstance(ckpt_obj, dict):
        # 顶层字典中若有典型键，按优先级替换
        for key in ["state_dict", "model", "net", "model_state_dict"]:
            if key in ckpt_obj and isinstance(ckpt_obj[key], dict):
                ckpt_obj[key] = fused
                return ckpt_obj

        # 顶层就是 state_dict 的情形
        if ckpt_obj and all(isinstance(k, str) for k in ckpt_obj.keys()) and any(
            isinstance(v, torch.Tensor) for v in ckpt_obj.values()
        ):
            return fused

        # 实在找不到合适位置，就新增一个 'state_dict' 键
        ckpt_obj["state_dict"] = fused
        return ckpt_obj

    # 其他类型（极少见），直接返回 fused
    return fused


def _intersect_keys_with_same_shape(dicts: List[Dict[str, torch.Tensor]]) -> List[str]:
    """取所有 state_dict 的共同键，且这些键的 tensor 形状一致"""
    common = None
    for sd in dicts:
        keys = set(sd.keys())
        if common is None:
            common = keys
        else:
            common &= keys
    if not common:
        return []
    # 过滤掉形状不一致的键
    keys = []
    for k in sorted(common):
        shape = dicts[0][k].shape
        if all(tuple(sd[k].shape) == tuple(shape) for sd in dicts[1:]):
            keys.append(k)
    return keys


def _maybe_keep_fp32(t: torch.Tensor, keep_fp32: bool) -> torch.Tensor:
    if keep_fp32 and t.is_floating_point():
        return t.to(torch.float32)
    return t


def average_fuse_state_dicts(
    state_dicts: List[Dict[str, torch.Tensor]],
    weights: List[float],
    keep_fp32: bool = True,
) -> Tuple[Dict[str, torch.Tensor], Dict[str, int]]:
    """
    将多个 state_dict 做加权平均融合。
    仅融合公共且形状一致的键。返回：(fused_state, stats)
    stats: {'fused_keys': N, 'skipped_keys_first': M}
    """
    if len(state_dicts) == 0:
        raise ValueError("state_dicts 为空")
    if len(weights) != len(state_dicts):
        raise ValueError(f"weights 数量({len(weights)})需与 state_dicts 数量({len(state_dicts)})一致")

    weights_t = torch.tensor(weights, dtype=torch.float64)
    if torch.allclose(weights_t, torch.zeros_like(weights_t)):
        raise ValueError("weights 不能全为 0")
    weights_t = weights_t / weights_t.sum()

    common_keys = _intersect_keys_with_same_shape(state_dicts)
    fused = {}
    for k in common_keys:
        acc = None
        for sd, w in zip(state_dicts, weights_t):
            v = sd[k]
            v = _maybe_keep_fp32(v, keep_fp32)
            if acc is None:
                acc = v.detach().clone() * float(w)
            else:
                acc.add_(v, alpha=float(w))
        fused[k] = acc

    # 统计
    stats = {
        "fused_keys": len(common_keys),
        "skipped_keys_first": len(state_dicts[0]) - len(common_keys),
    }
    return fused, stats


def main():
    ap = argparse.ArgumentParser(description="平均融合多个模型的权重并输出融合模型")
    ap.add_argument("--models", type=str, required=False,
                    help="模型路径列表：逗号分隔 'a.pickle,b.pickle' 或 '@list.txt'")
    ap.add_argument("--weights", type=str, default=None,
                    help="融合权重，逗号分隔，与 models 数量一致；默认等权")
    ap.add_argument("--output", type=str, required=False, help="输出融合后的模型路径，例如 model/model-fused.pickle")
    ap.add_argument("--keep-fp32", action="store_true", default=True, help="融合时将浮点权重先转为 float32 再平均")
    ap.add_argument("--dry-run", action="store_true", help="仅打印将要融合的键统计信息，不落盘")
    args = ap.parse_args()

    args.models = [
        'model/class7_model/model-2460000-fused.pickle',
        'model/class7_model/model-2546000-fused.pickle',
    ]
    args.output_step = 2550000
    args.output = f'model/class7_model/model-{args.output_step}-fused.pickle'


    model_paths = [str(Path(p).expanduser().resolve()) for p in args.models]
    if len(model_paths) < 2:
        raise SystemExit("至少指定两个模型用于融合")

    if args.weights:
        weights = [float(x) for x in args.weights.split(",") if x.strip() != ""]
        if len(weights) != len(model_paths):
            raise SystemExit("weights 数量需与 models 数量一致")
    else:
        weights = [1.0] * len(model_paths)

    # 加载所有 checkpoint 并提取 state_dict
    ckpts = []
    sds = []
    for p in model_paths:
        obj = torch.load(p, map_location="cpu")
        sd = _extract_state_dict(obj)
        if not sd:
            raise SystemExit(f"无法从 {p} 提取 state_dict，请检查 checkpoint 结构")
        ckpts.append(obj)
        sds.append(sd)
    print(f"已加载 {len(sds)} 个模型")

    fused_state, stats = average_fuse_state_dicts(sds, weights=weights, keep_fp32=args.keep_fp32)
    print(f"可融合参数数: {stats['fused_keys']}；首个模型被跳过参数数: {stats['skipped_keys_first']}")
    if stats["fused_keys"] == 0:
        raise SystemExit("没有可融合的共同参数，请确认模型结构一致")

    if args.dry_run:
        print("dry-run 模式：不保存融合模型")
        return

    # 将融合后的 state_dict 写回第一个 checkpoint 的结构中，并保存为目标文件
    fused_obj = _replace_state_dict_in_ckpt(ckpts[0], fused_state)
    # 附加元信息
    meta = {
        "fused_from": model_paths,
        "weights": weights,
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "tool": "fusion_models.py",
        "note": "average fused state_dict",
    }
    if isinstance(fused_obj, dict):
        fused_obj.setdefault("_fusion_meta", meta)
    # 保存
    out_path = Path(args.output).expanduser().resolve()
    out_path.parent.mkdir(parents=True, exist_ok=True)
    fused_obj['step'] = args.output_step
    torch.save(fused_obj, str(out_path))
    print(f"融合模型已保存: {out_path}")


if __name__ == "__main__":
    main()
