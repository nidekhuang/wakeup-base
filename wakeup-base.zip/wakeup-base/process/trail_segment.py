import sys
import torch
import numpy as np
from pathlib import Path
from tools.stft_istft import *
from train.train_script_1mic import *
from process.deploy_mdtc_norm import MDTCSML

def gen_target_file_list(target_dir, target_ext='.wav'):
    l = []
    for root, dirs, files in os.walk(target_dir, followlinks=True):
        for f in files:
            f = os.path.join(root, f)
            ext = os.path.splitext(f)[1]
            ext = ext.lower()
            if ext == target_ext and '._' not in f:
                l.append(f)
    return l


if __name__ == '__main__':
    threshold = 0.5
    num_classes= 7
    model_dir = 'model/class7_model'
    input_dir = 'test/wake-0912/LPI-seg'
    suffix = 'pcm'
    type = 'pcm'
    device = 'cuda:0'

    # network
    net_work = MDTCSML(stack_num=4, stack_size=4, in_channels=64, res_channels=128, kernel_size=7, causal=True, num_classes=num_classes+1)
    net_work = net_work.to(device)
    net_work.eval()
    # net_work.fuse_module()
    # net_work.eval()

    # models
    models = gen_target_file_list(model_dir, '.pickle')
    models = [model for model in models if 'fuse' not in model and 'mat' not in model]
    models.sort(key=lambda x: x.split('-')[1])
    models = models
    models = [
        'model/class7_model/model-2125000--118.7786205291748.pickle',
    ]
    # scenes
    scenes = [item for item in os.listdir(input_dir) if os.path.isdir(os.path.join(input_dir, item))]
    scenes.sort()

    # logs
    log_path = f'{input_dir}/log-{type}.csv'
    log_writer = open(log_path, 'a')
    log_writer.write(f"file, {', '.join(scenes)}\n")

    for model in models:
        # each model
        resume_model(net_work, Path(model).parent, Path(model).stem)
        # each scene
        results = []
        total_count = 0
        for scene in scenes:
            files = gen_target_file_list(os.path.join(input_dir, scene, type), '.' + suffix)
            files.sort()
            scene_count = [0] * num_classes
            for file in files:
                if suffix == 'wav':
                    mix, sr = sf.read(file)
                elif suffix == 'pcm':
                    # mix, sr = sf.read(file, channels=1, samplerate=16000, format='RAW', subtype='FLOAT')
                    mix, sr = sf.read(file, channels=2, samplerate=16000, format='RAW', subtype='PCM_16')
                else:
                    raise NotImplementedError
                if len(mix.shape) == 1:
                    mix = np.reshape(mix, [-1, 1])

                # temp: APP错误导致NLPI只有一个通道输出，取第一通道
                if 'NLPI' in scene or 'NLPI' in input_dir:
                    mix = mix[:, :1]

                mag_cum = []
                scores = []
                indexs = []
                for i in range(mix.shape[1]):
                    mix_c = torch.from_numpy(mix[:, i].astype(np.float32))
                    with torch.no_grad():
                        mix_c = mix_c.unsqueeze(dim=0).to(device)
                        t = mix_c.size(-1)
                        est, mag = net_work(mix_c)
                        score, max_idx = (torch.softmax(est, dim=-1).squeeze()[:, 1:]).max(1)
                        scores.append(score)
                        indexs.append(max_idx)
                        mag_cum.append(torch.cumsum(mag.squeeze(0).sum(1), dim=0))
                scores = torch.stack(scores, axis=0)
                indexs = torch.stack(indexs, axis=0)
                mag_cum = torch.stack(mag_cum, axis=0)

                is_wake = False
                for frame_idx in range(scores.shape[1]):
                    if is_wake:
                        break
                    min_cum_mag = np.inf
                    best_score_mag = -1
                    best_channel_mag = 0
                    best_keyword_id_mag = 0
                    for ch in range(scores.shape[0]):
                        ch_score = scores[ch][frame_idx].item()
                        ch_id = indexs[ch][frame_idx].item()

                        if mag_cum[ch][frame_idx] < min_cum_mag:
                            min_cum_mag = mag_cum[ch][frame_idx]
                            cur_score = ch_score
                            cur_ch = ch
                            cur_id = ch_id
                        
                    if cur_score > threshold:
                        is_wake = True
                        wake_count = 1
                        scene_count[cur_id] += 1
                        total_count += 1
                        break

                print(f"{Path(file).stem}, {cur_id + 1 if is_wake else None}")
            results.append(scene_count)
            print('{} has process!'.format(scene), scene_count)
        log_writer.write(f"{Path(model).stem}, {', '.join([str(item) for item in results])}, total_count={total_count}\n")
        log_writer.flush()
            