import torch
import random
import einops
import numpy as np
import torch.nn as nn
import torch.nn.functional as F

class STFT(torch.nn.Module):
    def __init__(self, 
                 fft_size=1024, 
                 hop_size=512,
                 win_size=None,
                 window='sqrt_hann',
                 sample_rate=16000,
                 dtype='float32'):
        super(STFT, self).__init__()
        self.fft_size = fft_size
        self.hop_size = hop_size
        self.win_size = fft_size if win_size is None else win_size 
        self.sample_rate = sample_rate
        self.dtype = dtype

        # check
        assert self.fft_size >= self.win_size
        assert self.win_size > self.hop_size and self.fft_size >= self.win_size
        assert window in ['rectangle', 'hanning', 'hamming', 'sqrt_hann', 'sine', 'vorbis', 'blackman-harris', 'blackman-nuttal']
        
        self.register_buffer('win', torch.from_numpy(self.get_win(window, self.win_size)))

    @staticmethod
    def _tail_pad(x, win_size, hop_size):
        """
        params:
            x: audio samples, batched, [N, T] 
        """
        tail_frame_size = (x.shape[1] - win_size) % hop_size
        if tail_frame_size != 0:
            tail_padding = hop_size - tail_frame_size
            x = torch.nn.functional.pad(x, [0, tail_padding])
        return x
    
    def get_win(self, window, Nx):
        if window is None or window == 'rectangle':
            win = np.ones(Nx, dtype=np.float32)
        elif window in ['sqrt_hann', 'sine']:
            win = np.sqrt(np.hanning(Nx).astype(np.float32))
        elif window == 'vorbis':
            x = np.linspace(0, Nx, Nx + 1)[:-1]
            win = np.sin(np.pi / 2 * (np.sin(np.pi * x / Nx) ** 2))
        elif window == 'blackman-harris':
            x = np.linspace(0, Nx, Nx + 1)[:-1]
            a0 = 0.35875
            a1 = 0.48829
            a2 = 0.14128
            a3 = 0.01168
            win = a0 - a1 * np.cos(np.pi * 2 * x / Nx) + a2 * np.cos(np.pi * 4 * x / Nx) - a3 * np.cos(6 * np.pi * x / Nx)
        elif window == 'blackman-nuttal':
            x = np.linspace(0, Nx, Nx + 1)[:-1]
            a0 = 0.3635819
            a1 = 0.4891775
            a2 = 0.1365995
            a3 = 0.0106411
            win = a0 - a1 * np.cos(np.pi * 2 * x / Nx) + a2 * np.cos(np.pi * 4 * x / Nx) - a3 * np.cos(6 * np.pi * x / Nx)
        else:
            win = getattr(np, window)(Nx)
        return win

    def pre_emphasis(self, x, alpha=0.97):
        """_summary_

        Args:
            x (numpy.array): input array, [N, T]
            alpha (float, optional): filter coeffcient. Defaults to 0.97.

        Returns:
            x: emphasized signal
        """
        ndim = x.ndim
        if ndim == 1:
            x = x[None]

        x = torch.nn.functional.pad(x, [1, 0], mode='replicate')
        x = x[:, 1:] - alpha * x[:, :-1]

        if ndim == 1:
            x = x[0]

        return x

    def ctransform(self, x, keep_dc=True):
        re, im = self.transform(x, keep_dc)
        return re + im * 1j

    def transform(self, x, keep_dc=True):

        if x.dtype not in [torch.float32, torch.float64]:
            x = x.float()

        input_shape = x.size()
        if len(input_shape) == 1:
            x = x[None]

        x = x.reshape(int(np.prod(input_shape[:-1])), x.shape[-1])

        x = STFT._tail_pad(x, self.win_size, self.hop_size)

        spec = torch.stft(
            input=x, 
            n_fft=self.fft_size, 
            hop_length=self.hop_size, 
            win_length=self.win_size, 
            window=self.win.to(x.dtype), 
            center=True, 
            pad_mode='constant', 
            onesided=True,
            return_complex=True,
        )  # B, F, T

        spec = spec.transpose(1, 2) # B T F
        re = spec.real
        im = spec.imag

        if not keep_dc:
            re = re[..., 1:]
            im = im[..., 1:]

        out_shape = re.shape
        re = re.reshape(*input_shape[:-1], out_shape[-2], out_shape[-1])
        im = im.reshape(*input_shape[:-1], out_shape[-2], out_shape[-1])

        return re, im
    
    def cinverse(self, cspec):
        # shape [..., time, freq]
        return self.inverse(cspec.real, cspec.imag)
    
    def inverse(self, re, im):
        """_summary_

        Args:
            re (torch.Tensor): shape [..., time, freq]
            im (torch.Tenspr): shape [..., time, freq]

        Returns:
            sig (torch.Tensor): shape [..., num_samples]
        """


        if re.dtype == torch.float16:
            re = re.float()
            im = im.float()

        input_shape = re.size()
        if len(input_shape) == 2:
            re = re[None]
            im = im[None]

        re = re.reshape(int(np.prod(input_shape[:-2])), *input_shape[-2:])
        im = im.reshape(int(np.prod(input_shape[:-2])), *input_shape[-2:])
        # repair dropped direct current
        if re.size(2) == self.fft_size // 2:
            re = torch.nn.functional.pad(re, [1, 0, 0, 0])
            im = torch.nn.functional.pad(im, [1, 0, 0, 0])

        spec = re + im * 1j
        spec = spec.transpose(1, 2)
        sig = torch.istft(
            input=spec, 
            n_fft=self.fft_size, 
            hop_length=self.hop_size, 
            win_length=self.win_size, 
            window=self.win, 
            center=True,
            onesided=True
        )

        out_shape = sig.shape
        sig = sig.reshape(*input_shape[:-2], out_shape[-1])

        return sig
    
    def mag(self, x, keep_dc=True, eps=1e-8):
        re, im = self.transform(x, keep_dc)
        mag = torch.clamp(re ** 2 + im ** 2, min=eps**2) ** 0.5
        return mag

    def mag_phase(self, x, keep_dc=True, eps=1e-8):
        re, im = self.transform(x, keep_dc)
        mag = torch.clamp(re ** 2 + im ** 2, min=eps**2) ** 0.5
        phase = torch.atan2(im, re + eps)
        return mag, phase

    def mag_phase_inverse(self, mag, phase):
        if mag.shape != phase.shape:
            raise ValueError("mag's shape and phase's shape is not same.")
        re = mag * torch.cos(phase)
        im = mag * torch.sin(phase)
        return self.inverse(re, im)

    def forward(self, x, keep_dc=True):
        re, im = self.transform(x, keep_dc=keep_dc)
        sig = self.inverse(re, im)
        return sig

class SpeechConv(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, stride, padding, dilation=1, out_ac=None, is_bn=True):
        super(SpeechConv, self).__init__()
        self.cnn = nn.Conv2d(in_channels=in_channels, out_channels=out_channels, kernel_size=kernel_size, stride=stride,
                             padding=padding, dilation=dilation, bias=True)
        self.ac = out_ac

    def forward(self, in_feat):
        res = self.cnn(in_feat)
        if self.ac is not None:
            res = self.ac(res)
        return res

class SpeechDeConv(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, padding=None, out_ac=None, is_bn=True):
        super(SpeechDeConv, self).__init__()
        self.cnn = nn.Conv2d(in_channels=in_channels, out_channels=out_channels, kernel_size=kernel_size, stride=1,
                             padding=padding, bias=True)
        self.ac = out_ac

    def forward(self, in_feat):
        res = self.cnn(in_feat)
        if self.ac is not None:
            res = self.ac(res)
        b, c, t, f = res.size()
        res = res.reshape(b, 2, c // 2, t, f).permute(0, 2, 3, 4, 1).reshape(b, c // 2, t, -1)
        return res

class TCNConv(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, padding, dilation=1, out_ac=None, is_bn=True):
        super(TCNConv, self).__init__()
        self.cnn = nn.Conv1d(in_channels=in_channels, out_channels=out_channels, kernel_size=kernel_size,
                             padding=0, dilation=dilation, bias=True)
        self.padding = padding
        self.ac = out_ac

    def forward(self, in_feat, hidden=None):
        if hidden is None:
            pad_feat = F.pad(in_feat, [self.padding, 0])
        else:
            pad_feat = torch.cat([hidden, in_feat], dim=-1)
            
        res = self.cnn(pad_feat)
        if self.ac is not None:
            res = self.ac(res)
        return res, pad_feat[:, :, -self.padding:]

class Model(nn.Module):
    def __init__(
            self,
            n_mics=2,
            fft_size=512,
            hop_size=256,
            t_context=5,
            f_context=8,
            enc_chs=[20, 20, 20, 16, 16, 16],
            dec_chs=[20, 20, 20, 16, 16, 16],
            tcn_kernels=3,
            tcn_dilations=[1, 2, 4, 8, 16, 32],
            rnn_layers=2,
            eps=1e-8
        ):
        super(Model, self).__init__()
        assert len(enc_chs) == len(dec_chs)
        
        ### basics
        self.n_mics = n_mics
        self.fft_size = fft_size
        self.hop_size = hop_size
        self.t_context = t_context
        self.f_context = f_context
        self.tcn_layers = len(tcn_dilations)
        self.rnn_layers = rnn_layers
        self.eps = eps
        self.stft = STFT(fft_size=fft_size, hop_size=hop_size)

        ### layers define
        self.in_norm = nn.LayerNorm([t_context * n_mics * 2, f_context])
        self.encoder = nn.ModuleList()      # encoder: 320 - 160 - 80 - 40 - 20 - 10 - 5
        self.tcns = nn.ModuleList()         # tcns: 4 * in_chs[-1]
        self.lstms = nn.LSTM                # lstms: 4 * in_chs[-1]
        self.lstms_vad = nn.Linear          # lstm_vad: - 2
        self.decoder_pres = nn.ModuleList() # decoder: 5 - 10 - 20 - 40 - 80 - 160
        self.mask_fork = SpeechConv         # forks: mask fork & angle fork - 320
        self.angle_fork = SpeechConv        # forks: mask fork & angle fork - 320


        ### Initial
        # encoder
        for ich, och in zip([t_context * n_mics * 2, *enc_chs[:-1]], enc_chs):
            self.encoder += [SpeechConv(
                in_channels=ich, 
                out_channels=och, 
                kernel_size=[1, 3], 
                stride=[1, 2], 
                padding=[0, 1], 
                out_ac=nn.PReLU(och)
            )]

        # tcns
        self.mid_channels = enc_chs[-1]
        self.mid_features = fft_size // 2 // (2 ** len(enc_chs))
        mid_size = self.mid_channels * self.mid_features
        for d in tcn_dilations:
            self.tcns += [TCNConv(
                in_channels=mid_size, 
                out_channels=mid_size, 
                kernel_size=tcn_kernels, 
                padding=(tcn_kernels-1)*d, 
                dilation=d, 
                out_ac=nn.PReLU(mid_size)
            )]

        # lstms
        self.lstms = self.lstms(
            input_size=mid_size, 
            hidden_size=mid_size, 
            num_layers=rnn_layers, 
            batch_first=True
        )
        self.lstms_vad = self.lstms_vad(mid_size, n_mics)

        # decoder pres
        inv_enc_chs = enc_chs[::-1]
        inv_dec_chs = dec_chs[::-1]
        for sch, ich, och in zip(inv_enc_chs, inv_dec_chs, inv_dec_chs[1:]):
            self.decoder_pres += [SpeechDeConv(
                in_channels=ich + sch, 
                out_channels=och * 2, 
                kernel_size=[1, 3], 
                padding=[0, 1], 
                out_ac=nn.PReLU(och * 2)
            )]
        
        # decoder forks
        self.mask_fork = SpeechDeConv(
            in_channels=inv_enc_chs[-1] + inv_dec_chs[-1], 
            out_channels = n_mics * 2, 
            kernel_size=(1, 3),
            padding=(0, 1), 
            out_ac=torch.sigmoid
        )
        self.angle_fork = SpeechDeConv(
            in_channels=inv_enc_chs[-1] + inv_dec_chs[-1], 
            out_channels= n_mics * 4, 
            kernel_size=(1, 3),
            padding=(0, 1)
        )

    def angle_norm(self, spec, complex_dim=-1):
        mag = ((spec ** 2).sum(complex_dim, keepdims=True) + 1e-7).sqrt()
        norm_spec = spec / (mag + 1e-6)
        return norm_spec

    def clear_buffer(self, buffer):
        if buffer is None:
            return {}
        elif self.training and random.random() < 0.2:
            return {}
        else:
            return buffer

    def l2_regularization(self, l2_alpha=1):
        l2_loss = []
        for module in self.modules():
            if type(module) is nn.Conv2d or type(module) is nn.Conv1d:
                l2_loss.append((module.weight ** 2).mean())
            elif type(module) is nn.LSTM:
                for name, param in module.named_parameters():
                    if 'weight_ih' in name or 'weight_hh' in name:
                        l2_loss.append((param ** 2).mean())
        return l2_alpha * torch.stack(l2_loss, dim=0).mean()

    def l2_regularization_feature(self, features, l2_alpha=0.01):
        l2_loss = []
        for feat in features:
            l2_loss.append((feat ** 2).mean())
        return l2_alpha * torch.stack(l2_loss, dim=0).mean()

    def forward(self, mix):
        """ufork forwad

        Args:
            inputs (dict): inputs dict {
                "mix": [B, 2, T],
                "buffer": {}
            }

        Returns:
            outputs (dict): outputs dict{
                "predict_wav": [B, 2, T],
                "buffer": {}
            }
        """
        with torch.no_grad():

            # spec
            buffer = self.clear_buffer(None)
            mr, mi = self.stft.transform(mix, keep_dc=False)

            # make in batch
            batch, channel, time, freq = mr.shape
            in_spec = torch.stack([mr, mi], dim=2) # b c (r/i) t f
            
            # context
            in_feat = einops.rearrange(in_spec, 'b c ri t f-> b (c ri) t f')
            in_feat = F.pad(in_feat, (0, 0, 0, self.t_context - 1), 'constant', 0)
            # unfold==> b c t_context freq time
            in_feat = in_feat.unfold(dimension=2, size=time, step=1) 
            in_feat = einops.rearrange(in_feat, 'b c ctx f t-> b (ctx c) t f')
        
        # regulation feat
        features = []

        # feat norm
        assert freq % self.f_context == 0, "in_norm freq cannot divide by f_context"
        norm_feat = einops.rearrange(in_feat, 'b c t (f1 fctx)->b t f1 c fctx', fctx=self.f_context)
        norm_feat = self.in_norm(norm_feat)
        norm_feat = einops.rearrange(norm_feat, 'b t f1 c fctx-> b c t (f1 fctx)')

        # encoder
        out = norm_feat
        enc_skips = []
        for layer in self.encoder:
            out = layer(out)
            enc_skips += [out]
            features += [out]

        # tcns
        out = einops.rearrange(out, 'b c t f->b (f c) t') # b f t
        tcn_skip = []
        tcn_hidden = {}
        for k, layer in enumerate(self.tcns):
            out, hidden = layer(out, buffer.get('tcn', {}).get(k, None))
            tcn_skip += [out]
            features += [out]
            tcn_hidden[k] = hidden.detach()
        tcn_skip = torch.stack(tcn_skip, dim=1).mean(dim=1)
        tcn_skip = einops.rearrange(tcn_skip, 'b f t->b t f')
        buffer['tcn'] = tcn_hidden

        # lstm
        lstm_out, lstm_hidden = self.lstms(tcn_skip, buffer.get('lstm', None))
        out = einops.rearrange(lstm_out * tcn_skip, 'b t (f c)->b c t f', f=self.mid_features)
        lstm_hidden = tuple(lstm_hidden[k].detach() for k in range(self.rnn_layers))
        buffer['lstm'] = lstm_hidden

        # decoder
        for layer, skip in zip(self.decoder_pres, enc_skips[::-1]):
            out = layer(torch.cat([out, skip], dim=1))
            features += [out]

        # forks
        pmask = self.mask_fork(torch.cat([out, enc_skips[0]], dim=1))
        pmask = einops.rearrange(pmask, 'b (c e) t f->b c t f e', e=1)
        pangle = self.angle_fork(torch.cat([out, enc_skips[0]], dim=1))
        pangle = einops.rearrange(pangle, 'b (c e) t f->b c t f e', e=2)
        pangle = self.angle_norm(pangle, complex_dim=-1)
        # lstm-vad
        pvad = torch.sigmoid(self.lstms_vad(lstm_out))
        pvad = einops.rearrange(pvad, 'b t (f e1 e2) -> b f t e1 e2', e1=1, e2=1)
        

        # result
        mmag = torch.clamp(mr ** 2 + mi ** 2, min=self.eps**2).sqrt()
        mmag = mmag.unsqueeze(dim=-1)
        pspec = mmag * pmask * pangle * pvad
        preal = pspec[..., 0]
        pimag = pspec[..., 1]
        predict_wav = self.stft.inverse(preal, pimag)

        return predict_wav

def resume_model(net, models_path):
    model_dict = torch.load(models_path, map_location=torch.device('cpu'), weights_only=False)
    state_dict = model_dict['model']
    net.load_state_dict(state_dict, False)

def gen_net(model_path):
    net = Model(
        **{
            "n_mics": 2,
            "fft_size": 512,
            "hop_size": 256,
            "t_context": 5,
            "f_context": 8,
            "enc_chs": [20, 20, 20, 16, 16, 16],
            "dec_chs": [20, 20, 20, 16, 16, 16],
            "tcn_kernels": 3,
            "tcn_dilations": [1, 2, 4, 8, 16, 32],
            "rnn_layers": 2,
        }
    )
    resume_model(net, model_path)
    net.eval()
    return net

if __name__ == "__main__":

    m = Model(
        **{
            "n_mics": 4,
            "fft_size": 512,
            "hop_size": 256,
            "t_context": 1,
            "f_context": 8,
            "enc_chs": [20, 20, 20, 16, 16, 16],
            "dec_chs": [20, 20, 20, 16, 16, 16],
            "tcn_kernels": 3,
            "tcn_dilations": [1, 2, 4, 8, 16, 32],
            "rnn_layers": 2,
        }
    )
    
    x = {
        "mix": torch.randn(1, 4, 16000),
    }