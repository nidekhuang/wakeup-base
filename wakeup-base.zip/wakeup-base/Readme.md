# Wakeup-Base 唤醒词检测训练项目

## 项目概述

本项目是一个基于深度学习的语音唤醒词检测系统，使用单麦克风输入进行训练。核心模型采用 MDTC (Multi-scale Dilated Temporal Convolutional) 网络结构，支持分布式训练和动态数据增强。

---

## 目录结构

```
wakeup-base/
├── train/
│   ├── train_script_1mic.py    # 主训练脚本
│   └── model_handle.py         # 模型保存/加载工具
├── network/
│   └── mdtc.py                 # MDTCSML 网络定义
├── settings/
│   └── config.py               # 配置参数
├── simulate_data/
│   └── gen_simulate_data_car_zone.py  # 数据生成与增强
└── README.md
```

---

## 训练流程概述

```
┌─────────────────────────────────────────────────────────────────┐
│                        训练流程图                                │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  1. 初始化阶段                                                   │
│     ├── 设置随机种子 (set_seed)                                  │
│     ├── 初始化 Accelerator (分布式训练)                          │
│     ├── 创建 MDTCSML 网络                                        │
│     └── 加载 GPUDataSimulate (数据增强模块)                       │
│                                                                 │
│  2. 数据加载阶段                                                 │
│     ├── CZDataset: 加载原始音频数据                               │
│     └── BatchDataLoader: 批量数据加载器                           │
│                                                                 │
│  3. 数据增强阶段 (GPU端)                                         │
│     ├── 频率响应模拟 (TRAIN_FRQ_RESPONSE)                        │
│     ├── 道路噪声添加 (ROAD_SNR_LIST)                             │
│     ├── 点噪声添加 (POINT_SNR_LIST)                              │
│     └── 车载区域模型处理 (zone_model)                             │
│                                                                 │
│  4. 模型训练阶段                                                 │
│     ├── 前向传播: 计算 logist, loss, acc                         │
│     ├── 反向传播: 计算梯度                                       │
│     ├── 梯度裁剪: clip_grad_norm (0.01)                          │
│     └── 参数更新: optimizer.step()                               │
│                                                                 │
│  5. 保存与监控阶段                                               │
│     ├── 定期打印 loss/acc (PRINT_TIMES)                          │
│     ├── 定期保存模型 (TEST_TIMES)                                │
│     └── 保存验证音频样本                                         │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## 核心组件详解

### 1. 网络模型 (MDTCSML)

```python
MDTCSML(stack_num=4, stack_size=4, in_channels=64, res_channels=128, kernel_size=7, causal=True)
```

| 参数 | 值 | 说明 |
|------|-----|------|
| `stack_num` | 4 | 堆叠块数量 |
| `stack_size` | 4 | 每个堆叠块的层数 |
| `in_channels` | 64 | 输入通道数 |
| `res_channels` | 128 | 残差通道数 |
| `kernel_size` | 7 | 卷积核大小 |
| `causal` | True | 因果卷积（实时推理） |

**模型输入/输出：**
- 输入: `enhance_data` - 增强后的音频特征
- 输出: `logist` (分类logits), `loss`, `acc`, `vad_speech`

### 2. 数据生成模块 (GPUDataSimulate)

在 GPU 端进行实时数据增强，包括：

| 增强类型 | 配置参数 | 作用 |
|----------|----------|------|
| 频率响应 | `TRAIN_FRQ_RESPONSE` | 模拟不同麦克风/环境的频率响应 |
| 道路噪声 | `ROAD_SNR_LIST` | 添加车载环境噪声 |
| 点噪声 | `POINT_SNR_LIST` | 添加定向噪声源 |
| 区域模型 | `zone_model_path` | 车载声学区域建模 |

### 3. 数据集 (CZDataset)

```python
CZDataset(
    PIN_YIN_CONFIG_PATH,      # 拼音配置路径
    TRAINING_KEY_WORDS,       # 关键词音频目录
    TRAINING_BACKGROUND,      # 背景音频目录
    TRAINING_NOISE,           # 噪声音频目录
    TRAINING_RIR,             # 房间冲激响应目录
    POINT_NOISE_PATH,         # 点噪声目录
    error_kws_dir=ERROR_KWS_DIR,  # 错误关键词目录
    sample_rate=16000,
    speech_seconds=10
)
```

### 4. 分布式训练 (Accelerator)

使用 HuggingFace Accelerate 库实现分布式训练：

```python
Accelerator(kwargs_handlers=[DistributedDataParallelKwargs(find_unused_parameters=True)])
```

---

## 配置参数说明

需要在 `settings/config.py` 中配置以下参数：

```python
# 数据路径配置
PIN_YIN_CONFIG_PATH = "..."      # 拼音配置文件
TRAINING_KEY_WORDS = "..."       # 训练关键词目录
TRAINING_BACKGROUND = "..."      # 背景音频目录
TRAINING_NOISE = "..."           # 噪声目录
TRAINING_RIR = "..."             # RIR目录
POINT_NOISE_PATH = "..."         # 点噪声目录
ERROR_KWS_DIR = "..."            # 错误关键词目录

# 数据增强参数
TRAIN_FRQ_RESPONSE = [...]       # 频率响应列表
ROAD_SNR_LIST = [...]            # 道路噪声SNR范围
POINT_SNR_LIST = [...]           # 点噪声SNR范围

# 训练参数
BATCH_SIZE = 32                  # 批大小
LR = 0.001                       # 学习率
PRINT_TIMES = 100                # 打印间隔
TEST_TIMES = 1000                # 保存/测试间隔

# 模型配置
MODEL_DIR = "..."                # 模型保存目录
MODEL_NAME = "..."               # 模型名称
RESUME_MODEL = False             # 是否恢复训练
TRAINING_CHECK_PATH = "..."      # 验证样本保存路径
```

---

## 运行方法

### 单卡训练

```bash
cd /datapool/deep_learning/userspace/zhangkanghao/code/wakeup-base
python -m train.train_script_1mic
```

### 多卡分布式训练

```bash
# 使用 accelerate 启动
accelerate launch --num_processes=4 train/train_script_1mic.py

# 或使用 torchrun
torchrun --nproc_per_node=4 train/train_script_1mic.py
```

### 恢复训练

在 `settings/config.py` 中设置：

```python
RESUME_MODEL = True
MODEL_NAME = "checkpoint_xxxx.pt"  # 指定要恢复的模型
```

---

## 训练监控

### 日志输出

训练过程会定期输出以下信息：

```
step = 100, loss - 0.xxxx, acc - 0.xxxx, c_acc - 0.xxxx
```

| 指标 | 说明 |
|------|------|
| `loss` | 综合损失值 |
| `acc` | 关键词检测准确率 |
| `c_acc` | 自定义关键词准确率 |

### 验证样本

每 `TEST_TIMES` 步会保存验证音频到 `TRAINING_CHECK_PATH`：

- `{idx}_enhance_{target}_{pred}.wav` - 增强后音频
- `{idx}_vad_{target}_{pred}.wav` - VAD处理后音频

---

## 常见修改场景

### 1. 修改网络结构

编辑 `network/mdtc.py` 中的 `MDTCSML` 类，或在训练脚本中修改参数：

```python
net_work = MDTCSML(
    stack_num=6,       # 增加堆叠数
    res_channels=256,  # 增加通道数
    ...
)
```

### 2. 修改数据增强策略

修改 `simulate_data/gen_simulate_data_car_zone.py` 中的 `GPUDataSimulate` 类。

### 3. 修改学习率调度

在优化器后添加学习率调度器：

```python
optim = torch.optim.Adam(...)
scheduler = torch.optim.lr_scheduler.StepLR(optim, step_size=10000, gamma=0.5)

# 在训练循环中
optim.step()
scheduler.step()
```

### 4. 添加更多监控

取消注释 TensorBoard 相关代码：

```python
if rank == 0 and is_need_dataloader:
    writer = SummaryWriter('runs/train_log')
    
# 训练循环中
writer.add_scalar('loss/loss', avg_loss, step)
```

---

## 依赖环境

```bash
pip install torch accelerate tensorboardX soundfile numpy
```

主要依赖版本要求：
- Python >= 3.8
- PyTorch >= 1.10
- accelerate >= 0.20

---

## 注意事项

1. **随机种子**: 每个进程使用不同的随机种子确保数据多样性
2. **梯度裁剪**: 使用 `clip_grad_norm_(0.01)` 防止梯度爆炸
3. **NaN检测**: 当检测到梯度为 NaN 时跳过该步更新
4. **Hidden状态**: 模型使用隐藏状态 `train_hidden` 进行序列建模

---

## 问题排查

| 问题 | 可能原因 | 解决方案 |
|------|----------|----------|
| 梯度NaN | 学习率过大/数据异常 | 降低LR/检查数据 |
| OOM | batch_size过大 | 减小BATCH_SIZE |
| 训练卡住 | 数据加载瓶颈 | 增加workers_num |
| 准确率不提升 | 数据增强过强 | 调整SNR范围 |
